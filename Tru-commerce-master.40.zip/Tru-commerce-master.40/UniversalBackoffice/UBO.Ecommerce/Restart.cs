﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBO.Ecommerce
{
   public class RestartValues
   {
      public Int32 Transaction { get; set; }

   }
   public class Restart
   {

      private static volatile Restart instance;
      private static Object _classLock = typeof(Restart);
      private string restartfile = "restart";


      private Restart()
      {
         Process p = Process.GetCurrentProcess();
         restartfile = Path.GetDirectoryName(p.MainModule.FileName) + "\\" + restartfile;
      }
     

      public int GetTransaction()
      {
         RestartValues r = null;
         if (!File.Exists(restartfile))
         {
            r = new RestartValues();
            r.Transaction = 1;
         }
         else
         {
            r = JsonConvert.DeserializeObject<RestartValues>(File.ReadAllText(restartfile));
            r.Transaction++;
         }
         File.WriteAllText(restartfile, JsonConvert.SerializeObject(r));
         return (r.Transaction);
      }
      public void Eod()
      {
         RestartValues r = null;
         if (!File.Exists(restartfile))
         {
            r = new RestartValues();
            r.Transaction = 1;

         }
         else
         {
            r = JsonConvert.DeserializeObject<RestartValues>(File.ReadAllText(restartfile));
            r.Transaction=1;
         }
         File.WriteAllText(restartfile, JsonConvert.SerializeObject(r));
      }

      public static Restart Instance
      {
         get
         {
            if (instance == null)
            {
               lock (_classLock)
               {
                  if (instance == null)
                     instance = new Restart();
               }
            }
            return instance;
         }
      }
   }
}
