﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using eCommerceWebServiceClient;
//using eCommerceWebServiceClient.Models;
using Newtonsoft.Json;
using Universal.Core.Model;
using Universal.Infrastructure.Acs;
using Universal.Infrastructure.Acs.IO;
using System.Threading;
using System.IO;


[assembly: log4net.Config.XmlConfigurator(Watch = true)]
//[assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config", ConfigFileExtension=".config", Watch = true)]

namespace UBO.Ecommerce
{
   class Program
   {
      private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
      static void LoadConfig()
      {
         UniversalConfig config = UniversalConfig.Instance;
         string configfilename = "Universal.Config.json";
#if DEBUG
         File.Delete(configfilename);
#endif
         if (File.Exists(configfilename))
         {
            config.Config = JsonConvert.DeserializeObject<Config>(File.ReadAllText(configfilename));
         }
         else
         {
            log.InfoFormat("Creating default config file: {0}", configfilename);

            Config _Config = new Config();
            _Config.BgfPath = @"c:\acs\server\bgf";
            _Config.InfPath = @"c:\acs\server\migrate\inf";
            _Config.TlogPath = @"c:\acs\server\bgf\HighOME";
            _Config.RestartHour = 4; // restart at 4 am
            _Config.WhiteList.Add("SRTERM");
            _Config.WhiteList.Add("TCF");
            _Config.WhiteList.Add("DESCOP");
            _Config.WhiteList.Add("TDROPT");
            _Config.WhiteList.Add("DEPDEF");
            _Config.WhiteList.Add("STROPT");
            _Config.WhiteList.Add("PLU");
            _Config.WhiteList.Add("TLOG");
            _Config.BlackList.Add("CLOST");
            _Config.PutTransaction.UseWeightProvided = false;
            _Config.PutTransaction.TimeToLive = 0;
            _Config.UsePOSPrice = false;
            _Config.DoNotPingTms = false;
            _Config.SellNOFasDeptartment = true;
            config.Config = _Config;
            File.WriteAllText(configfilename, JsonConvert.SerializeObject(config.Config));

         }
      }
      static void LoadTruConfig()
      {
         TruCommerceConfig config = TruCommerceConfig.Instance;
         string configfilename = "TruCommerce.Config.json";
#if DEBUG
         File.Delete(configfilename);
#endif
         if (File.Exists(configfilename))
         {
            config.Cfg = JsonConvert.DeserializeObject<Cfg>(File.ReadAllText(configfilename));
         }
         else
         {
            log.InfoFormat("Creating default config file: {0}", configfilename);
            Cfg _Cfg = new Cfg();
            _Cfg.OrderServiceUrl = "https://testingecommerce.timeforgedev.com/v2/orderService";
            _Cfg.UserName = "acstest-1401"; //"mycloud-acs";//
            _Cfg.Password = "ws-acstest-1401"; //"mycloudp@";//
            _Cfg.Operator = "999";
            _Cfg.Terminal = 99;
            _Cfg.OrderCheckIntervalInMinutes = 15;
            _Cfg.ItemcodeContainsCheckDigit = true;
           

            config.Cfg = _Cfg;
            File.WriteAllText(configfilename, JsonConvert.SerializeObject(config.Cfg));

         }
         if (config.Cfg.Terminal >= 256)
         {
            Console.WriteLine("Error: Terminal value in TruCommerce.Config.json must be less than 256");
            Environment.Exit(-1);
         }
      }
      static void RestartTime(int hour)
      {

          if (hour < 1 || hour > 24) hour = 4;

          DateTime Now = DateTime.Now;

          DateTime Midnight = new DateTime(Now.Year, Now.Month, Now.Day, 23, 59, 59).AddHours(hour);

          TimeSpan ts = Midnight - Now;

          var milliseconds = ts.Milliseconds;

          System.Timers.Timer timer = new System.Timers.Timer();

          timer.Elapsed += (obj, args) =>
          {

              Tms.Term();

              log.InfoFormat("Performing daily restart... ");

              Environment.Exit(0);

          };

          timer.Interval = milliseconds;

          timer.AutoReset = false;

          timer.Start();



          //Task.Delay(ts).ContinueWith((x) =>

          //{

          //    Tms.Term();

          //    log.InfoFormat("Performing daily restart... ");

          //    Environment.Exit(0);

          //});

      }
      private static Int32 CheckTms(DataManager dm)
      {
         while (true)
         {
            dm.TmsUp();
            Thread.Sleep(60000);
         }
      }

      private static Int32 ProcessOrders(DataManager dm,TruCommerceConfig Cfg)
      {
         while (true)
         {
            OrderProcessor p = new OrderProcessor(dm, Cfg);
            p.Run();
            Thread.Sleep(Cfg.Cfg.OrderCheckIntervalInMinutes*60000);
         }
      }
      static public void SetUpESclose()
      {
         string entry = "system(\"c:\\\\ubo\\\\UBO.Ecommerce.exe eod\");";
         string plfile = "c:\\acs\\server\\bin\\e_sclose.pl";
         bool done = false;


         using (StreamWriter file = new StreamWriter(plfile+".ubo"))
         {
            foreach (string line in File.ReadLines("c:\\acs\\server\\bin\\e_sclose.pl"))
            {

               if (line.Contains(entry))
               {
                  done = true;
                  break;
               }
               if (line.Replace(" ","").Contains("exit(0);"))
               {
                  file.WriteLine(entry);
                  file.WriteLine("");
               }
               file.WriteLine(line);
            }
         }
         if (done)
         {
            File.Delete(plfile + ".ubo");
         }
         if (File.Exists(plfile + ".ubo"))
         {
            File.Delete(plfile);
            File.Move(plfile + ".ubo", plfile);
         }
      }
      static bool CheckHighHome()
      {
         if (!Directory.Exists(@"C:\ACS\Server\Bgf\HighOME"))
         {
            Directory.CreateDirectory(@"C:\ACS\Server\Bgf\HighOME");
         }
         File.WriteAllText(@"C:\ACS\Server\Bgf\HighOME\extended.bgf", DefaultTlog.Extended);
         
         if (File.Exists(@"C:\ACS\Server\Bgf\HighOME\item.bgf") &&
            File.Exists(@"C:\ACS\Server\Bgf\HighOME\tender.bgf") &&
            File.Exists(@"C:\ACS\Server\Bgf\HighOME\tax.bgf") &&
             File.Exists(@"C:\ACS\Server\Bgf\HighOME\leader.bgf") &&
            File.Exists(@"C:\ACS\Server\Bgf\HighOME\tblock.bgf"))
         {
            return (false);
         }
         File.WriteAllText(@"C:\ACS\Server\Bgf\HighOME\item.bgf", DefaultTlog.Item);
         File.WriteAllText(@"C:\ACS\Server\Bgf\HighOME\tender.bgf", DefaultTlog.Tender);
         File.WriteAllText(@"C:\ACS\Server\Bgf\HighOME\tax.bgf", DefaultTlog.Tax);
         File.WriteAllText(@"C:\ACS\Server\Bgf\HighOME\tblock.bgf", DefaultTlog.Tblock);
         File.WriteAllText(@"C:\ACS\Server\Bgf\HighOME\leader.bgf", DefaultTlog.Leader);
         return (true);
      }
      static void DelHighHome()
      {
         if (File.Exists(@"C:\ACS\Server\Bgf\HighOME\item.bgf")) File.Delete(@"C:\ACS\Server\Bgf\HighOME\item.bgf");
         if (File.Exists(@"C:\ACS\Server\Bgf\HighOME\tender.bgf")) File.Delete(@"C:\ACS\Server\Bgf\HighOME\tender.bgf");
         if (File.Exists(@"C:\ACS\Server\Bgf\HighOME\tax.bgf")) File.Delete(@"C:\ACS\Server\Bgf\HighOME\tax.bgf");
         if (File.Exists(@"C:\ACS\Server\Bgf\HighOME\tblock.bgf")) File.Delete(@"C:\ACS\Server\Bgf\HighOME\tblock.bgf");
         if (File.Exists(@"C:\ACS\Server\Bgf\HighOME\leader.bgf")) File.Delete(@"C:\ACS\Server\Bgf\HighOME\leader.bgf");

      }
      static int Main(string[] args)
      {

         log.InfoFormat("Starting {0}", Environment.CommandLine);

         if (args.Length > 0 && args[0] == "eod")
         {
            Restart.Instance.Eod();
            return(0);
         }
         SetUpESclose();

         short TmsError = Tms.Init();

         if (TmsError != (short)Tms.Errors.OK)
         {
            log.FatalFormat("Unable to connect with TMS.  Exiting.");
            return (-1);
         }
         try
         {

            LoadConfig();
            LoadTruConfig();
            UniversalConfig.Instance.Config.Operator = TruCommerceConfig.Instance.Cfg.Operator;
            bool created = CheckHighHome();
            DataManager dm = DataManager.Instance; // preload everything to it's not done on first request.
            if (created)
            {
               DelHighHome();
            }

            if (File.Exists(@"C:\ACS\Server\Bgf\HighOME\extended.bgf")) File.Delete(@"C:\ACS\Server\Bgf\HighOME\extended.bgf");

            log.InfoFormat("Configured to process the following files:");
            foreach (AcsFile f in dm.Fd.Files)
            {
               log.InfoFormat("\t{0}", f.Name);
            }
            Tms.TmsErrorEvent += Tms_TmsErrorEvent;

            if (UniversalConfig.Instance.Config.DoNotPingTms == false)
            {
               Task<Int32> t = new Task<Int32>(n => CheckTms(dm), 1000);
               t.Start();
            }

            //RestartTime(UniversalConfig.Instance.Config.RestartHour);
            RestartTimer r = new RestartTimer();
            r.hour = UniversalConfig.Instance.Config.RestartHour;
            ThreadStart threadDelegate = new ThreadStart(r.Start);
            Thread newThread = new Thread(threadDelegate);
            newThread.Start();

            Task<Int32> Orders = new Task<Int32>(n => ProcessOrders(dm, TruCommerceConfig.Instance), 1000);
            Orders.Start();

            Console.WriteLine("Processing Orders, press ENTER to exit");
            Console.ReadLine();


         }
         catch (Exception e)
         {
            log.Fatal("Unhandled exception", e);
         }
         finally
         {
            Tms.Term();
         }
         return (0);
      }


      private static void Tms_TmsErrorEvent(object sender)
      {
         log.Fatal("Unrecoverable TMS error, exiting.");
         Console.WriteLine("Unrecoverable TMS error, exiting.");
         Environment.Exit(-1);
      }
   }
}
