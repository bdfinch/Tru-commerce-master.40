﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBO.Ecommerce
{

   public class Cfg
   {
      public String UserName { get; set; }
      public String Password { get; set; }
      public String OrderServiceUrl { get; set; }
      public Int32 Terminal { get; set; }
      public string Operator { get; set; }
      public bool ItemcodeContainsCheckDigit { get; set; }
      public Int32 OrderCheckIntervalInMinutes { get; set; }
   }

   public class TruCommerceConfig
   {
      private static volatile TruCommerceConfig instance;
      private static Object _classLock = typeof(TruCommerceConfig);
      private Cfg _Cfg = null;
      public Cfg Cfg
      {
         get
         {
            return _Cfg;
         }
         set
         {
            if (_Cfg == null)
            {
               // only allow this to be set once
               _Cfg = value;
            }
         }
      }
      public static TruCommerceConfig Instance
      {
         get
         {
            if (instance == null)
            {
               lock (_classLock)
               {
                  if (instance == null)
                     instance = new TruCommerceConfig();
               }
            }
            return instance;
         }
      }
   }
}

