﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace UBO.Ecommerce
{
   public class RestartTimer
   {
      public int hour { get; set; }
      public void Start()
      {
         if (hour < 1 || hour > 24) hour = 4;
         while (true)
         {
            Thread.Sleep(1000 * 60 * 9);  // check every nine minutes
            DateTime Now = DateTime.Now;
            if(Now.Hour == hour  && Now.Minute < 10 )
            {
                Environment.Exit(0);
            }
         }
      }
   }
}
