﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBO.Ecommerce
{

   public static class DefaultTlog
   {
      public const string Item =
"FILE      dc.001" + "\n" +
"RECORD    000 0121 GTLITM-I" + "\n" +
"FIELD     01 code UP 000 007" + "\n" +
"FIELD     02 filler UC 007 001" + "\n" +
"FIELD     02 xprice LG 008 004" + "\n" +
"FIELD     02 price1 LG 012 004" + "\n" +
"FIELD     02 price2 LG 016 004" + "\n" +
"FIELD     02 department UI 020 002" + "\n" +
"FIELD     02 family_code01 UI 022 002" + "\n" +
"FIELD     02 family_code02 UI 024 002" + "\n" +
"FIELD     02 family_code03 UI 026 002" + "\n" +
"FIELD     02 flags UL 028 004" + "\n" +
"FIELD     02 itemizers UI 032 002" + "\n" +
"FIELD     02 dis_sc_value LG 034 004" + "\n" +
"FIELD     02 report_code UC 038 001" + "\n" +
"FIELD     02 sal_media UC 039 001" + "\n" +
"FIELD     02 type UC 040 001" + "\n" +
"FIELD     02 access UC 041 001" + "\n" +
"FIELD     02 quanwgt LG 042 004" + "\n" +
"FIELD     02 dealqty UI 046 002" + "\n" +
"FIELD     02 pmethod UC 048 001" + "\n" +
"FIELD     02 filler UC 049 001" + "\n" +
"FIELD     02 mix_match_code UI 050 002" + "\n" +
"FIELD     02 min_order_amt LG 052 004" + "\n" +
"FIELD     02 spooled_msg IN 056 002" + "\n" +
"FIELD     02 alt_price LG 058 004" + "\n" +
"FIELD     02 alt_qty UI 062 002" + "\n" +
"FIELD     02 str_order_code LG 064 004" + "\n" +
"FIELD     02 coupon_count01 UC 068 001" + "\n" +
"FIELD     02 coupon_count02 UC 069 001" + "\n" +
"FIELD     02 coupon_count03 UC 070 001" + "\n" +
"FIELD     02 coupon_count04 UC 071 001" + "\n" +
"FIELD     02 coupon_count05 UC 072 001" + "\n" +
"FIELD     02 nsc5_error_type UC 073 001" + "\n" +
"FIELD     02 pace_setter_code UC 074 001" + "\n" +
"FIELD     02 plu_condiment_list_log UC 075 001" + "\n" +
"FIELD     02 reason_code IN 076 002" + "\n" +
"FIELD     01 price_change_type S3 078 002" + "\n" +
"FIELD     02 markdown_amt LG 080 004" + "\n" +
"FIELD     02 sale_price LG 084 004" + "\n" +
"FIELD     02 sale_deal UI 088 002" + "\n" +
"FIELD     02 pim_condiments1 UI 090 002" + "\n" +
"FIELD     02 pim_condiments2 UI 092 002" + "\n" +
"FIELD     04 UPC128_NSC CH 094 001" + "\n" +
"FIELD     01 UPC128_HHID S3 095 008" + "\n" +
"FIELD     01 UPC128_expiration_date_month S3 103 002" + "\n" +
"FIELD     01 UPC128_expiration_date_year S3 105 002" + "\n" +
"FIELD     01 UPC128_offer_code S3 107 005" + "\n" +
"FIELD     02 max_pim_xprice LG 112 004" + "\n" +
"FIELD     02 sales_EntryID UL 116 004" + "\n" +
"FIELD     02 man_coupon_mult_level UC 120 001" + "\n" +
"INCLUDE  tlogdef1.h" + "\n" +
"END" + "\n";
      public const string Tender = 
"FILE      dc.001" + "\n" +
"RECORD    000 0072 GTLTEN-Q" + "\n" +
"FIELD     01 account S3 000 024" + "\n" +
"FIELD     02 type IN 024 002" + "\n" +
"FIELD     02 amount LG 026 004" + "\n" +
"FIELD     02 foreign_tender_amount LG 030 004" + "\n" +
"FIELD     02 flag IN 034 002" + "\n" +
"FIELD     01 approval_code S3 036 009" + "\n" +
"FIELD     02 sub_tender_number UC 045 001" + "\n" +
"FIELD     02 ref_no UL 046 004" + "\n" +
"FIELD     02 cas_ref_no UL 050 004" + "\n" +
"FIELD     02 prim_acct IN 054 002" + "\n" +
"FIELD     01 state_mnemonic S3 056 003" + "\n" +
"FIELD     02 unused2 UC 059 001" + "\n" +
"FIELD     02 itemize_subtotal LG 060 004" + "\n" +
"FIELD     02 domestic_amount LG 064 004" + "\n" +
"FIELD     02 sales_EntryID UL 068 004" + "\n" +
"INCLUDE  tlogdef1.h" + "\n" +
"END" + "\n";
      public const string Tax =
"FILE      dc.001" + "\n" +
"RECORD    000 0032 GTLTAX-t" + "\n" +
"FIELD     02 tax01 LG 000 004" + "\n" +
"FIELD     02 tax02 LG 004 004" + "\n" +
"FIELD     02 tax03 LG 008 004" + "\n" +
"FIELD     02 tax04 LG 012 004" + "\n" +
"FIELD     02 gross01 LG 016 004" + "\n" +
"FIELD     02 gross02 LG 020 004" + "\n" +
"FIELD     02 gross03 LG 024 004" + "\n" +
"FIELD     02 gross04 LG 028 004" + "\n" +
"INCLUDE  tlogdef1.h" + "\n" +
"END" + "\n";
      public const string Tblock =
"FILE      dc.001" + "\n" +
"RECORD    000 0020 GTLTBH-B  " + "\n" +
"FIELD     04 type CH 000 001" + "\n" +
"FIELD     02 tlog_seq_count UC 001 001" + "\n" +
"FIELD     02 terminal UI 002 002" + "\n" +
"FIELD     02 sequence UI 004 002" + "\n" +
"FIELD     02 numblock UI 006 002" + "\n" +
"FIELD     02 tnum UL 008 004" + "\n" +
"FIELD     02 non_reset_tnum UL 012 004" + "\n" +
"FIELD     02 period UL 016 004" + "\n" +
"INCLUDE  tlogdef1.h" + "\n" +
"END" + "\n";

      public const string Leader =
"FILE dc.001" + "\n" +
"RECORD    000 0058 GTLLDR-L" + "\n" +
"FIELD     02 type UI 000 002" + "\n" +
"FIELD     02 year UC 002 001" + "\n" +
"FIELD     02 month UC 003 001" + "\n" +
"FIELD     02 day UC 004 001" + "\n" +
"FIELD     02 hour UC 005 001" + "\n" +
"FIELD     02 minute UC 006 001" + "\n" +
"FIELD     02 second UC 007 001" + "\n" +
"FIELD     01 operator S3 008 010" + "\n" +
"FIELD     01 zip_code S3 018 005" + "\n" +
"FIELD     02 filler UC 023 001" + "\n" +
"FIELD     02 store_number UI 024 002" + "\n" +
"FIELD     02 perf_times01 UL 026 004" + "\n" +
"FIELD     02 perf_times02 UL 030 004" + "\n" +
"FIELD     02 perf_times03 UL 034 004" + "\n" +
"FIELD     02 perf_times04 UL 038 004" + "\n" +
"FIELD     02 perf_times05 UL 042 004" + "\n" +
"FIELD     02 flags UI 046 002" + "\n" +
"FIELD     02 sgpos LG 048 004" + "\n" +
"FIELD     02 sgneg LG 052 004" + "\n" +
"FIELD     02 numtrans IN 056 002" + "\n" +
"INCLUDE tlogdef1.h" + "\n" +
"END" + "\n";
      public const string Extended =
"FILE dc.001" + "\n" +
"RECORD    000 0010 EXTEND-FF" + "\n" +
"FIELD     02 extended_record_type UC 000 001" + "\n" +
"FIELD     02 expt_flag UC 001 001" + "\n" +
"FIELD     02 size_of_entry IN 002 002" + "\n" +
"FIELD     02 type_of_entry IN 004 002" + "\n" +
"FIELD     02 offset_to_user_data IN 006 002" + "\n" +
"FIELD     02 hdr_version IN 008 002" + "\n" +
"INCLUDE tlogdef1.h" + "\n" +
"END" + "\n";

      //       typedef struct {
      //UC extended_record_type;
      //    UC expt_flag;                         /* exception log flag
      //                                         (Must be 2nd byte)                */
      //    IN size_of_entry;                     /* size of buffer to follow          */
      //    IN type_of_entry;                     /* tlog record type                  */
      //    IN offset_to_user_data;               /* user data offset                  */
      //    IN hdr_version;                       /* Record type version               */
      // }
      // EXTENDED_TLOG_HDR;

   }
}
