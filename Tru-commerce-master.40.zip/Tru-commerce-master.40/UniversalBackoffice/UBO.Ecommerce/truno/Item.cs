﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eCommerceWebServiceClient.Models
{
    public class Item
    {
        //The below was used by united's web services
        public string Barcode { get; set; }

        //public string Tag { get; set; } //already defined

        //public double Quantity { get; set; } //already defined

        //public string Price { get; set; } //already defined
        //End of united

        public string upc { get; set; }

        public string Tag { get; set; }

        public string quantity { get; set; }

        public string price { get; set; }

        public string department { get; set; }

        public string weight { get; set; }
    }
}
