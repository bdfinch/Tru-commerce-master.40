﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eCommerceWebServiceClient.Models
{
   public class Tax
   {
     public string id { get; set; }
     public string taxCode { get; set; }
     public string taxableAmount { get; set; }
     public string taxAmount { get; set; }
   }
}
