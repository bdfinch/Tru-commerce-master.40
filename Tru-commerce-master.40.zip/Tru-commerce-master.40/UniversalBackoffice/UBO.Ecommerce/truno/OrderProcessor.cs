﻿using eCommerceWebServiceClient.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Universal.Core.Model;
using Universal.Infrastructure.Acs;
using Universal.Infrastructure.Acs.IO;

namespace UBO.Ecommerce
{
   public class OrderProcessor
   {
      private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

      private DataManager _dm;
      private TruCommerceConfig _Cfg;
      public OrderProcessor(DataManager Dm, TruCommerceConfig Cfg)
      {
         _dm = Dm;
         _Cfg = Cfg;
      }

      // debug code to change the type from attended to unattended or visa versa
      private void SetType(string Type, Sale sale)
      {
         ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
         sale.type = Type;
         string json = JsonConvert.SerializeObject(sale);
         string uri = _Cfg.Cfg.OrderServiceUrl + "/" + sale.id;

         //var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "mwg/order/" + orderNumber);
         var httpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
         httpWebRequest.Timeout = 3000000;
         httpWebRequest.ContentType = "application/json";
         httpWebRequest.Method = "PUT";


         if (_Cfg.Cfg.UserName != "" && _Cfg.Cfg.Password != "")
         {
            string credentials = _Cfg.Cfg.UserName + ":" + _Cfg.Cfg.Password;
            Log.Info("Credentials detected, adding them to the request header.");
            //The below log file is a security risk. Only use when debugging!
            Log.Info("Credentials are not blank, adding the following credentials to the header: " + credentials);
            httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials)));
            httpWebRequest.PreAuthenticate = true;
         }

         using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
         {
            streamWriter.Write(json);
         }


         using (var response = (HttpWebResponse)httpWebRequest.GetResponse())
         {
            if (response.StatusCode != HttpStatusCode.Accepted && response.StatusCode != HttpStatusCode.OK)
            {
               Log.Error("Execute of PUT query has failed " + uri);
            }
            else
            {
               Log.Info("PUT query was executed  " + uri);
            }
         }

      }
      private void SetStatus(string Status, Sale sale)
      {
         ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
         sale.status = Status;
         string json = JsonConvert.SerializeObject(sale);
         string uri = _Cfg.Cfg.OrderServiceUrl + "/" + sale.id;

         //var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "mwg/order/" + orderNumber);
         var httpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
         httpWebRequest.Timeout = 3000000;
         httpWebRequest.ContentType = "application/json";
         httpWebRequest.Method = "PUT";


         if (_Cfg.Cfg.UserName != "" && _Cfg.Cfg.Password != "")
         {
            string credentials = _Cfg.Cfg.UserName + ":" + _Cfg.Cfg.Password;
            Log.Info("Credentials detected, adding them to the request header.");
            //The below log file is a security risk. Only use when debugging!
            Log.Info("Credentials are not blank, adding the following credentials to the header: " + credentials);
            httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials)));
            httpWebRequest.PreAuthenticate = true;
         }

         using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
         {
            streamWriter.Write(json);
         }


         using (var response = (HttpWebResponse)httpWebRequest.GetResponse())
         {
            if (response.StatusCode != HttpStatusCode.Accepted && response.StatusCode != HttpStatusCode.OK)
            {
               Log.Error("Execute of PUT query has failed " + uri);
            }
            else
            {
               Log.Info("PUT query was executed  " + uri);
            }
         }

      }
      private List<Sale> GetSalesByStatus()
      {
         List<Sale> sales = new List<Sale>();
         //debug to reset status of orders to 2
         //var httpWebRequest = (HttpWebRequest)WebRequest.Create(_Cfg.Cfg.OrderServiceUrl + "?status=3");
         var httpWebRequest = (HttpWebRequest)WebRequest.Create(_Cfg.Cfg.OrderServiceUrl + "?status=1");
         //httpWebRequest.Timeout = 3000000;
         //add in the credential header if they exist
         if (_Cfg.Cfg.UserName != "" && (_Cfg.Cfg.Password != ""))
         {
            string credentials = _Cfg.Cfg.UserName + ":" + _Cfg.Cfg.Password;
            //               Log.Info("Credentials detected, adding them to the request header.");
            //The below log file is a security risk. Only use when debugging!
            Log.Info("Credentials are not blank, adding the following credentials to the header: " + credentials);
            httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials)));
            httpWebRequest.PreAuthenticate = true;
         }

         Log.Info(httpWebRequest.RequestUri);

         ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

         string response;
         var resp = (HttpWebResponse)httpWebRequest.GetResponse();
         using (var s = resp.GetResponseStream())
         {
            using (var reader = new StreamReader(s))
            {
               response = reader.ReadToEnd();
               Log.Debug("Response: " + response.ToString());
            }
         }
         Log.Info("status request JSON=" + response);

         System.Threading.Thread.Sleep(500); //Wait half a second for the response.

         //     Program.statuscode = resp.StatusCode.ToString();

         if (resp.StatusCode != HttpStatusCode.OK)
         {
            Log.Error("Execute of GET query GetSalesByStatus() " + _Cfg.Cfg.OrderServiceUrl + "?status=1"+ " failed ");
         }
         else
         {
            Log.Info("Execute of GET query GetSalesByStatus() " + _Cfg.Cfg.OrderServiceUrl + "?status=1" + " successful ");
         }

         try
         {
            Log.Debug("Attempting to deserialize single order.");
            var Tmpsale = JsonConvert.DeserializeObject<Sale>(response, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            if(Tmpsale.id!=null)
            { 
               sales.Add(Tmpsale);
            }
            Log.Info("order was able to deserialize as a single order.");
            Log.Info("request JSON=" + response);
         }
         catch
         {
            Log.Info("Single order was unable to deserialize, attempting to Deserialize order as a list.");
            try
            {
               List<Sale> Listsale = JsonConvert.DeserializeObject<List<Sale>>(response,
                                                                    new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
               sales = Listsale;
               Log.Info("request JSON=" + response);
            }
            catch (Exception ex2)
            {
               Log.Error("Order was unable to deserialize. Exception: ", ex2);
            }

         }

         return (sales);
      }
      private PutTransaction CreatePutTransaction(Sale sale, bool Itemlookup)
      {
         PutTransaction p = new PutTransaction();
         p.Header.Store = _dm.GetStoreNumber();
         p.Header.Terminal = _Cfg.Cfg.Terminal;
         p.Header.Operator = TruCommerceConfig.Instance.Cfg.Operator;
         // use last 4 of the order ID as the transaction number
         p.Header.Transaction = Convert.ToInt32(sale.processorOrderNumber.Substring(sale.processorOrderNumber.Length - 4, 4));
         p.Header.Card = sale.posLoyaltyNumber;

         p.Header.GrossPositive = p.Header.Tax = Utils.NormalizeDecimal(sale.SalesTax, 2);
         // add tenders
         if (sale.orderEntryTenders != null)
         { 
            foreach (Tender t in sale.orderEntryTenders)
            {
               PutTender pt = new PutTender();
               pt.Amount = Utils.NormalizeDecimal(t.posTenderAmount, 2);
               pt.Type = Convert.ToInt32(t.posTenderType);
               p.Header.Tenders.Add(pt);
               p.Header.GrossPositive += pt.Amount;
            }
         }
         if (sale.orderEntryTaxes != null)
         {
            foreach (Tax t in sale.orderEntryTaxes)
            {
               PutTax pt = new PutTax();
               pt.Amount = Utils.NormalizeDecimal(t.taxAmount, 2);
               pt.TaxableAmount = Utils.NormalizeDecimal(t.taxableAmount, 2);
               pt.Code = Convert.ToInt32(t.taxCode);
               p.Header.Taxes.Add(pt);
            }
         }
         p.Items = new List<PutItem>();

         if (sale.orderEntryPOSs != null)
         {
            foreach (Item i in sale.orderEntryPOSs)
            {
               PutItem pi = new PutItem();
               pi.DefaultDept = Convert.ToInt16(i.department);

               if (!TruCommerceConfig.Instance.Cfg.ItemcodeContainsCheckDigit)
               {
                  pi.Item = i.upc.TrimStart('0');
               }
               else
               {
                  pi.Item = i.upc;
               }
               if (Itemlookup)
               {
                  pi.product = _dm.GetProduct(pi.Item);
                  if (pi.product != null)
                  {
                     foreach (dynamic d in _dm.Options.Departments)
                     {
                        if (d.deptno == pi.product.Department)
                        {
                           if (pi.product.OverrideAttributes)
                           {
                              pi.product.Flags = d.flags;
                              pi.product.Itemizers = d.itemizers;
                              pi.product.Tare = d.tare_code;
                              break;
                           }
                        }
                     }
                  }
               }
               pi.Price = Utils.NormalizeDecimal(i.price, 2);
               pi.Qty = Utils.NormalizeDecimal(i.quantity, 0);
               if (pi.Qty == 0)
               {
                  pi.Wgt = Utils.NormalizeDecimal(i.weight, 2);
                  //pi.PricePerPound;
               }
               if ((i.upc.TrimStart('0').Length == 11 && i.upc.TrimStart('0').StartsWith("2")) ||
                   (i.upc.Length == 14 && i.upc.TrimStart('0').StartsWith("2")))

               {  // special handling for imbedded weight

                  string tmp = pi.Price.ToString().PadLeft(5,'0');
                  if (i.upc.Length == 14)
                  {
                     i.upc = i.upc.Substring(0, 8) + tmp + i.upc.Substring(13, 1);
                  }
                  else
                  {
                     i.upc = i.upc.TrimStart('0');
                     i.upc = i.upc.Substring(0, 6) + tmp;
                  }
                  pi.Item = i.upc;
                  pi.NSC2 = true;
               }
               p.Items.Add(pi);
             }
         }

         return (p);
      }
      public void Run()
      {
         // test check to see if EOD in progress if is do not process
         TcfInfo tcfInfo = _dm.GetTfcInfo();
         if (tcfInfo.EodInProgress==true)
         {
            Log.Info("EOD in progress cannot process orders " + DateTime.Now.ToLocalTime());
            return;
         }


         List<Sale> sales = GetSalesByStatus();
         foreach(Sale sale in sales)
         {
            //debug to reset status of orders to 2
            //SetStatus("1", sale);
            //continue;
            try
            {
               Log.Info("processing order ID=" + sale.id.ToString() + " order number=" + sale.processorOrderNumber.ToString());
               Console.WriteLine("processing order ID=" + sale.id.ToString() + " order number=" + sale.processorOrderNumber.ToString());
               sale.posCashier = TruCommerceConfig.Instance.Cfg.Operator;
               sale.posLane = TruCommerceConfig.Instance.Cfg.Terminal.ToString();
 
               if (sale.type == "1" || sale.type == "3")
               {
                  PutTransaction p = CreatePutTransaction(sale,true);
                  // have to use a real tranaction number here
                  p.Header.Transaction = Restart.Instance.GetTransaction();
                  _dm.ProcessTlog(p, tcfInfo);

               }
               else if (sale.type == "2" || sale.type == "4")
               {
                  PutTransaction p = CreatePutTransaction(sale,false);
                  _dm.PutItemsInSuspendFile(p);
               }
               // debug code to set type to 2 for testing
               //SetType("2", sale);

               SetStatus("2", sale);
            }
            catch (Exception e)
            {
               Log.Error("Unable to process order. Exception: ", e);
               SetStatus("3", sale);
            }
         }
      }
   }
}
