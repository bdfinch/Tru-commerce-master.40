﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eCommerceWebServiceClient.Models
{
    public class Tender
    {
        public string posTenderType { get; set; }

        public string posTenderAmount { get; set; }

    }
}
