﻿namespace eCommerceWebServiceClient
{
    using System.IO;
    using System.Net;

    using log4net;
    using System.Text;
    using System;

    class Transaction
    {
//        private static readonly ILog Log = LogManager.GetLogger(typeof(Program));

        private string url;
        private string username;
        private string password;

        public Transaction(string url, string username, string password)
        {
            this.url = url;
            this.username = username;
            this.password = password;
        }
      //https://testingecommerce.timeforgedev.com/v2/orderService?type=2&status=2&processOrderNumber=3008
      public string GetDataByOrderNumber(string orderNumber)
        {
            //var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "mwg/order/" + orderNumber);
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "/" + orderNumber.ToString());
            //httpWebRequest.Timeout = 3000000;
            //add in the credential header if they exist
            if (username != "" && password != "")
            {
                string credentials = username + ":" + password;
 //               Log.Info("Credentials detected, adding them to the request header.");
                //The below log file is a security risk. Only use when debugging!
                //Log.Info("Credentials are not blank, adding the following credentials to the header: " + credentials);
                httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials)));
                httpWebRequest.PreAuthenticate = true;
            }
            
   //         Log.Info(httpWebRequest.RequestUri);

            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

            string response;
            var resp = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var s = resp.GetResponseStream())
            {
                using (var reader = new StreamReader(s))
                {
                    response = reader.ReadToEnd();
     //               Log.Debug("Response: " + response.ToString());
                }
            }

            System.Threading.Thread.Sleep(500); //Wait half a second for the response.

       //     Program.statuscode = resp.StatusCode.ToString();

            if (resp.StatusCode != HttpStatusCode.OK)
            {
         //       Log.Error("Execute of GET query was failed (Order=" + orderNumber.ToString() + ")");
            }
            else
            {
           //     Log.Info("GET query was executed (Order=" + orderNumber.ToString() + ")");
            }


            return response;
        }

        public string GetDataByUnprocessed()
        {
            //var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "mwg/order/" + orderNumber);
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "?status=1");
            httpWebRequest.Timeout = 3000000;
            //add in the credential header if they exist
            if (username != "" && password != "")
            {
                string credentials = username + ":" + password;
             //   Log.Info("Credentials detected, adding them to the request header.");
                //The below log file is a security risk. Only use when debugging!
                //Log.Info("Credentials are not blank, adding the following credentials to the header: " + credentials);
                httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials)));
                httpWebRequest.PreAuthenticate = true;
            }
            
            //Log.Info(httpWebRequest.RequestUri);


            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

            string response;
            var resp = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var s = resp.GetResponseStream())
            {
                using (var reader = new StreamReader(s))
                {
                    response = reader.ReadToEnd();
              //      Log.Debug("Response: " + response.ToString());
                }
            }

      //      Program.statuscode = resp.StatusCode.ToString();

            if (resp.StatusCode != HttpStatusCode.OK)
            {
        //        Log.Error("Execute of GET query was failed");
            }
            else
            {
          //      Log.Info("GET query was executed.");
            }


            return response;
        }

        public void SendData(string json, string orderNumber)
        {
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;


            //var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "mwg/order/" + orderNumber);
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url + "/" + orderNumber);
            httpWebRequest.Timeout = 3000000;
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "PUT";

            if (username != "" && password != "")
            {
                string credentials = username + ":" + password;
            //    Log.Info("Credentials detected, adding them to the request header.");
                //The below log file is a security risk. Only use when debugging!
                //Log.Info("Credentials are not blank, adding the following credentials to the header: " + credentials);
                httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials)));
                httpWebRequest.PreAuthenticate = true;
            }

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(json);
            }


            using (var response = (HttpWebResponse)httpWebRequest.GetResponse())
            {
              //  Program.statuscode = response.StatusCode.ToString();

                if (response.StatusCode != HttpStatusCode.Accepted && response.StatusCode != HttpStatusCode.OK)
                {
                //    Log.Error("Execute of PUT query has failed (Order=" + orderNumber + ")");
                }
                else
                {
                  //  Log.Info("PUT query was executed (Order=" + orderNumber + ")");
                }
            }
        }

        private string Execute(string method, string parameters)
        {
            return string.Empty;
        }
    }
}
