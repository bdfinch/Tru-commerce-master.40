﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eCommerceWebServiceClient.Models
{
    class OrderPutRequestV20
    {
        //Removed processorReceived because it can't be null in the PUT payload,
        //  and we don't want to overwrite it if it already exists
        //public string processorReceived { get; set; }
        public string processorOrderNumber { get; set; }
        public string processorLoyaltyNumber { get; set; }
        public string processorTenderAmount { get; set; }
        public string processorTenderType { get; set; }
        public string posReceived { get; set; }
        public string posOrderNumber { get; set; }
        public string posLoyaltyNumber { get; set; }
        public string posCashier { get; set; }
        public string posLane { get; set; }
        public string orderEntryProcessors { get; set; }
        public string status { get; set; }
        public string type { get; set; }
        public List<OrderDetailPutRequestV20> orderEntryPOSs { get; set; }
        public List<OrderTendersPutRequestV20> orderEntryTenders { get; set; }

    }
}
