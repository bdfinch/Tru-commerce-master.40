﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eCommerceWebServiceClient.Models
{
    class OrderDetailPutRequestV20
    {
        public string upc { get; set; }
        public string department { get; set; }
        public string price { get; set; }
        public string quantity { get; set; }
        public string weight { get; set; }
    }
}
