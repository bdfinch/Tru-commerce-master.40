﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eCommerceWebServiceClient.Models
{
    public class Sale
    {

        public string id { get; set; }

        public string version { get; set; }

        public string location { get; set; }

        public string processor { get; set; }

        public string processorOrderNumber { get; set; }

        public string processorLoyaltyNumber { get; set; }

        public string processorTenderAmount { get; set; }

        public string processorTenderType { get; set; }

//        public string processorReceived { get; set; }

        public string posReceived { get; set; }

        public string posOrderNumber { get; set; }

        public string posLoyaltyNumber { get; set; }

        public string posTenderAmount { get; set; }

        public string posTenderType { get; set; }

        public string posCashier { get; set; }

        public string posLane { get; set; }

        public string ProductTotal { get; set; }

        public string orderEntryProcessors { get; set; }

        public List<Item> orderEntryPOSs { get; set; }

        public List<Tender> orderEntryTenders { get; set; }

        public List<Tax> orderEntryTaxes { get; set; }

        public string OrderTotal { get; set; } //used by united

        public string SalesTax { get; set; }

        public string CouponsOwed { get; set; }

        public string PickFee { get; set; }

        public string DeliveryFee { get; set; }

        public string StoreId { get; set; }

        public string TicketNumber { get; set; }

        public string RegisterId { get; set; }

        public string TicketTotal { get; set; }

        public string TicketDateTime { get; set; }

 //       public List<Item> Items { get; set; } //used by united

        //public List<Guest> Guests { get; set; } //used by united

        public string status { get; set; }

        public string type { get; set; }

    }

    public class Sales
    {
        List<Sale> Orders { get; set; }
    }
}
