﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eCommerceWebServiceClient.Models
{
    class OrderTendersPutRequestV20
    {
        public string posTenderType { get; set; }
        public string posTenderAmount { get; set; }
    }
}
