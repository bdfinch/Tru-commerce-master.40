﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Universal.Core.Model;
using Universal.Infrastructure.Acs.IO;

namespace Universal.Infrastructure.Acs
{
   public partial class DataManager
   {
      Product ToProduct(AcsRecord record, byte[] binary)
      {
         Product p = new Product();
         dynamic Item = _Fd.ToDynamic(record, binary);
         p.Id = Item.key;
         p.Description = Item.desc;
         p.Department = Item.dept;
         p.Tare = Item.tare_code;
         p.Price = Item.prc1;
         p.Itemizers = Item.itemizers;
         p.Flags = Item.flags;
        // p.ExtendedItemizers = Item.extended_itemizers;

         p.OverrideAttributes =  Utils.IsBitSet(p.Flags, 19);//0x00080000
         return (p);
      }
      void ToBinary(Product p, AcsRecord record, byte[] binary, bool KeyOnly)
      {
         AcsIO.ManagedToBinary(binary, record.Fields.Where(n => n.Name == "key").First(), p.Id);
         if (KeyOnly == false)
         {
            AcsIO.ManagedToBinary(binary, record.Fields.Where(n => n.Name == "desc").First(), p.Description);
         }
      }

      public void WriteProduct(Product p)
      {
         lock(_classLock)
         {
            Tms _Tms = new Tms();
            if (_Tms != null)
            {
               _Tms.Open("PLU", true);
               if (p.Id != null)
               {
                  p.Id = AcsIO.Encode(p.Id);
                  AcsRecord record = _Fd.Files.Where(s => s.Name == "PLU").First().Records[0];
                  byte[] binary = new byte[record.Length];
                  ToBinary(p, record, binary, true);
                  _Tms.Read(binary, true);
                  ToBinary(p, record, binary, false);
                  _Tms.Write(binary, true);
               }
               _Tms.Close();
            }
         }
      }
      public Product GetProduct(string Id)
      {
         Product p = null;
         lock (_classLock)
         {
            Tms _Tms = new Tms();

            if (_Tms != null)
            {
               try
               {
                  p = new Product();
                  p.Id = Utils.Encode(Id);
                  _Tms.Open("PLU", false);
                  if (p.Id != null)
                  {
                     AcsRecord record = _Fd.Files.Where(s => s.Name == "PLU").First().Records[0];
                     byte[] binary = new byte[record.Length];
                     ToBinary(p, record, binary, true);
                     if (_Tms.Read(binary, true) == 0)
                     {
                        p = ToProduct(record, binary);
                     }
                     else
                     {
                        p = null;
                     }
                  }
               }
               catch(Exception e)
               {
                  p = null;
                  log.WarnFormat("Exception reading PLU record {0}, details {1}", Id,e.Message);
               }

               _Tms.Close();

            }
         }
         return (p);
      }
 
      public void DeleteProduct(Product p)
      {
         lock (_classLock)
         {
            Tms _Tms = new Tms();
            if (_Tms != null)
            {
               _Tms.Open("PLU", true);
               if (p.Id != null)
               {
                  p.Id = AcsIO.Encode(p.Id);
                  AcsRecord record = _Fd.Files.Where(s => s.Name == "PLU").First().Records[0];
                  byte[] binary = new byte[record.Length];
                  ToBinary(p, record, binary, true);
                  _Tms.Delete(binary, true);
               }
            }
         }
      }
   }
}
