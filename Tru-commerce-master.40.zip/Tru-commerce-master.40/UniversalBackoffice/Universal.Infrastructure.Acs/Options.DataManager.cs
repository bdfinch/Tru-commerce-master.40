﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Universal.Core.Model;
using Universal.Infrastructure.Acs.IO;

namespace Universal.Infrastructure.Acs
{

   public sealed partial class DataManager
   {
      private Options _Options = new Options();
      public Options Options { get { return (_Options); } }
      void Load()
      {
         lock(_classLock)
         {
            _Options.DepartmentDefintions.Clear();
            _Options.Departments.Clear();
            _Options.Tenders.Clear();
            Tms _Tms = new Tms();
            if (_Tms != null)
            {
               _Tms.Open("TDROPT", true);

               AcsFile file = _Fd.Files.Where(s => s.Name == "TDROPT").First();
               AcsRecord record = file.Records.Where(r => r.Name.ToUpper() == "OPTIONS_TDR_STRUCT").First();
               List <dynamic> tenders = new List<dynamic>();
               
               byte[] binary = new byte[record.Length];
               _Tms.First = true;
               while (_Tms.GetNext(binary) == (short)Tms.Errors.OK)
               {
                  if (_Tms.ioa.datalen == record.Length)
                  {
                     dynamic tender = _Fd.ToDynamic(record, binary);
                     if (tender.record > 1 && tender.record <65)
                     {
                        tenders.Add(tender);
                     }
                  }
               }
               _Options.Tenders = tenders;
               _Tms.Close();
            }
           
            if (_Tms != null)
            {
               _Tms.Open("STROPT", true);
               AcsFile file = _Fd.Files.Where(s => s.Name == "STROPT").First();
               AcsRecord record = file.Records.Where(r => r.Name.ToUpper() == "OPTIONS_STORE_STRUCT").First();
               _Tms.First = true;
               byte[] binary = new byte[record.Length];

               while (_Tms.GetNext(binary) == (short)Tms.Errors.OK)
               {
                  if (_Tms.ioa.datalen == record.Length)
                  {
                     dynamic store = _Fd.ToDynamic(record, binary);
                     if (store.reserved_record == 1)
                     {
                        _Options.Store = store;
                        break;
                     }
                  }
               }
               _Tms.Close();
            }
            if (_Tms != null)
            {
               _Tms.Open("DEPDEF", true);
               AcsFile file = _Fd.Files.Where(s => s.Name == "DEPDEF").First();
               AcsRecord record = file.Records.Where(r => r.Name.ToUpper() == "GDBDEPDEF").First();
               _Tms.First = true;
               byte[] binary = new byte[record.Length];

               while (_Tms.GetNext(binary) == (short)Tms.Errors.OK)
               {
                  if (_Tms.ioa.datalen == record.Length)
                  {
                     dynamic dept = _Fd.ToDynamic(record, binary);
                     if (dept.rec_num >0)
                     {
                        _Options.Departments.Add(dept);
                        _Options.DepartmentDefintions.Add(new DepartmentDefintions { Name = dept.deptdesc, Id = dept.deptno });
                     }
                  }
               }
               _Tms.Close();
            }
            if (_Tms != null)
            {
               _Tms.Open("DESCOP", true);
               AcsFile file = _Fd.Files.Where(s => s.Name == "DESCOP").First();
               AcsRecord record = file.Records.Where(r => r.Name.ToUpper() == "OPTIONS_DESC_STRUCT").First();
               _Tms.First = true;
               byte[] binary = new byte[record.Length];

               while (_Tms.GetNext(binary) == (short)Tms.Errors.OK)
               {
                  if (_Tms.ioa.datalen == record.Length)
                  {
                     dynamic desc = _Fd.ToDynamic(record, binary);
                     if (desc.reserved_record >0)
                     {
                        _Options.Description = desc;
                     }
                  }
               }
               _Tms.Close();
            }
         }
      }
   }
}
