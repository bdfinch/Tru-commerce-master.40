﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Dynamic;
using System.Collections;
using Universal.Infrastructure.Acs.IO;
using System.Globalization;

namespace Universal.Infrastructure.Acs.IO
{
   public static class AcsIO
   {
      //Tms Tms { get; set; }
      //FileDictionary FileDictionary { get; set; }
      //public AcsIO(Tms Tms, FileDictionary FileDictionary)
      //{
      //   this.Tms = Tms;
      //   this.FileDictionary = FileDictionary;
      //}
      public static void ManagedToBinary(byte[] record, AcsField field, object value)
      {
         if (value == null)
         {
            return; // nulls ok just means we don't overwrite anything
         }
         switch (field.Type)
         {
            case "UP":
               {
                  Array.Copy(StringToBcd((string)value), 0, record, field.Offset, field.Length);
                  break;
               }
            case "CH":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToSByte(value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "IN":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToInt16((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "LG":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToInt32((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "S3":
               {
                  string noquotes = (string)value;
                  if (noquotes.StartsWith("\""))
                  {
                     noquotes = noquotes.Remove(0, 1);
                  }
                  if (noquotes.EndsWith("\""))
                  {
                     noquotes = noquotes.Remove((noquotes.Length - 1), 1);
                  }
                  ASCIIEncoding ascii = new ASCIIEncoding();
                  byte[] tmp = ascii.GetBytes(noquotes);
                  int len = tmp.Length;
                  if (tmp.Length > field.Length)
                  {
                     len = field.Length;
                  }
                  Array.Copy(tmp, 0, record, field.Offset, len);
                  break;
               }
            case "SH":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToInt16((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "SZ":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToInt16((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "UC":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToByte((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "UI":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToUInt16((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "UL":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToUInt32((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "US":
               {
                  Array.Copy((BitConverter.GetBytes(Convert.ToUInt16((int)value))), 0, record, field.Offset, field.Length);
                  break;
               }
            case "VD":
               {
                  break;
               }
         }
      }
      public static object BinaryTo(byte[] record, AcsField field, int offset)
      {
         if (field.Type == "S3" || (field.Type == "CH" && field.ArrayLength >1) || field.Type == "UP")
         {
            return (string)(BinaryToString(record, field, offset));
         }
         return ((int)BinaryToInt(record, field, offset));
      }
      public static object BinaryTo(byte[] record, AcsField field)
      {
         return(BinaryTo(record, field, 0));
      }
      public static int BinaryToInt(byte[] record, AcsField field)
      {
         return (BinaryToInt(record, field, 0));
      }


      public static int BinaryToInt(byte[] record, AcsField field, int offset)
      {
         int location = field.Offset + offset;
         switch (field.Type)
         {
            case "UP":
               {
                  Debug.Assert(true, "UP not valid for int");
                  return (0);
               }
            case "CH":
               {
                  Debug.Assert(true, "CH not valid for int");
                  return (0);
               }
            case "IN":
               {
                  return ((int)BitConverter.ToInt16(record, location));

               }
            case "LG":
               {
                  return ((int)BitConverter.ToInt32(record, location));

               }
            case "S3":
               {
                  Debug.Assert(true, "S3 not valid for int");
                  return (0);
               }
            case "SH":
               {
                  return ((int)BitConverter.ToInt16(record, location));
               }
            case "SZ":
               {
                  return ((int)BitConverter.ToInt16(record, location));
               }
            case "UC":
               {
                  return ((int)record[location]);
               }
            case "UI":
               {
                  return ((int)BitConverter.ToUInt16(record, location));
               }
            case "UL":
               {
                  return ((int)BitConverter.ToUInt32(record, location));
               }
            case "US":
               {
                  return ((int)BitConverter.ToUInt16(record, location));
               }
            default:
               {
                  return (0);

               }
         }

      }
      public static string BinaryToString(byte[] record, AcsField field)
      {
         return (BinaryToString(record, field, 0));
      }
      public static string BinaryToString(byte[] record, AcsField field, int offset)
      {
         int location = field.Offset + offset;

         switch (field.Type)
         {
            case "UP":
               {
                  string TmpString = BitConverter.ToString(record, location, field.Length);
                  return (TmpString.Replace("-", ""));

               }
            case "CH":
               {
                  ASCIIEncoding ascii = new ASCIIEncoding();
                  String NewString = ascii.GetString(record, location, field.Length);
                  if (NewString.Length > 0)
                  {
                     if (NewString.Contains("\0"))
                     {
                        NewString = NewString.Remove(NewString.IndexOf("\0"), NewString.Length - NewString.IndexOf("\0"));
                     }
                  }
                  return (NewString);
               }
            case "IN":
               {
                  Debug.Assert(true, "IN not valid for string");
                  return ("");
               }
            case "LG":
               {
                  Debug.Assert(true, "LG not valid for string");
                  return ("");
               }
            case "S3":
               {
                  ASCIIEncoding ascii = new ASCIIEncoding();
                  String NewString = ascii.GetString(record, location, field.Length);
                  if (NewString.Length > 0)
                  {
                     if (NewString.Contains("\0"))
                     {
                        NewString = NewString.Remove(NewString.IndexOf("\0"), NewString.Length - NewString.IndexOf("\0"));
                     }
                  }
                  return (NewString);

               }
            case "SH":
               {
                  Debug.Assert(true, "SH not valid for string");
                  return ("");
               }
            case "SZ":
               {
                  Debug.Assert(true, "SZ not valid for string");
                  return ("");
               }
            case "UC":
               {
                  Debug.Assert(true, "UC not valid for string");
                  return ("");
               }
            case "UI":
               {
                  Debug.Assert(true, "UI not valid for string");
                  return ("");
               }
            case "UL":
               {
                  Debug.Assert(true, "UL not valid for string");
                  return ("");
               }
            case "US":
               {
                  Debug.Assert(true, "US not valid for string");
                  return ("");
               }
            default:
               {
                  return ("");
               }
         }

      }
      /// <summary>
      /// Returns whether the bit at the specified position is set.
      /// </summary>
      /// <typeparam name="T">Any integer type.</typeparam>
      /// <param name="t">The value to check.</param>
      /// <param name="pos">
      /// The position of the bit to check, 0 refers to the least significant bit.
      /// </param>
      /// <returns>true if the specified bit is on, otherwise false.</returns>
      public static bool IsBitSet<T>(this T t, int pos) where T : struct, IConvertible
      {
         bool rc = false;
         var value = t.ToInt64(CultureInfo.CurrentCulture);
         rc = (value & (1 << pos)) != 0;
         return (rc);
      }
      public static byte[] StringToBcd(string bcdstring)
      {
         ASCIIEncoding ascii = new ASCIIEncoding();
         byte[] asciibcdstring = ascii.GetBytes(Encode(bcdstring));
         byte[] bcd = new byte[asciibcdstring.Length / 2];
         int i = asciibcdstring.Length;

         while (i > 0)
         {
            int j = i / 2;
            bcd[j - 1] = (byte)(asciibcdstring[i - 1] - 0x30);
            i--;
            bcd[j - 1] = ((byte)(bcd[j - 1] + (asciibcdstring[i - 1] - 0x30) * 0x10));
            i--;
         }
         return (bcd);
      }
      public static string Normalize(string UPC)
      {
         if (UPC.Length == 7)
         {
            // get check digit
         }
         return (null);
      }
      #region PadItemCode
      //normalize the PLU code to 13 digits if it's less than 13
      public static string PadItemCode(String item_code)
      {
         string s = item_code;
         if (item_code.Length < 13)
         {
            s = item_code.PadLeft(13, '0');
         }
         return s;
      }
      #endregion

      #region AddCheckDigit
      // check digit algorithm
      //      For instance, the UPC-A barcode for a box of tissues is "036000241457". The last digit is the check digit "7", and if the other numbers are correct then the check digit calculation must produce 7.
      //
      //      1.Add the odd number digits: 0+6+0+2+1+5 = 14
      //      2.Multiply the result by 3: 14 × 3 = 42
      //      3.Add the even number digits: 3+0+0+4+4 = 11
      //      4.Add the two results together: 42 + 11 = 53
      //      5.To calculate the check digit, take the remainder of (53 / 10), which is also known as (53 modulo 10), and subtract from 10. Therefore, the check digit value is 7.
      //
      public static string AddCheckDigit(string item_code)
      {
         if (item_code.Length > 13)
         {
            return (item_code);
         }
         ASCIIEncoding encoder = new ASCIIEncoding();
         byte[] bytes = encoder.GetBytes(item_code);
         short oddtotal = 0;
         short eventotal = 0;
         string item = item_code;
         int counter = 0;
         foreach (byte a in bytes)
         {
            counter++;
            byte b = (byte)(a - 0x30);
            if (counter % 2 == 0)
            {
               eventotal += (short)b;
            }
            else
            {
               oddtotal += (short)b;
            }
         }
         short cd = (short)(((3 * oddtotal) + eventotal) % 10);
         if (cd > 0)
         {
            cd = (short)(10 - cd);
         }
         item = item_code + cd.ToString();
         return (item);
      }
      #endregion

      #region Encode
      //normalize the PLU code to 14 digits if it's less than 14
      public static string Encode(string Code)
      {
         string encoded = Code;
         if (Code == null)
         {
            encoded = Code = "00000000000000";
         }
         if (Code.Length < 15)  // if we're less than 15 assume NSC5 otherwise assume GS1
         {
            try
            {
               switch (Code.Length)
               {
                  // EAN-8 and UPCs of length 12, 13, or 14 already have check digit
                  case 8:
                  case 12:                                  //NSC5 with check digit
                  case 13:
                  case 14:
                     {
                        encoded = Code.PadLeft(14, '0');
                        break;
                     }
                  case 1:
                  case 2:
                  case 3:
                  case 4:
                  case 5:
                  case 6:
                  case 7:
                  case 9:
                  case 10:
                  case 11:                                  //NSC5 without check digit
                     {
                        encoded = AddCheckDigit(Code);
                        encoded = encoded.PadLeft(14, '0');
                        break;
                     }
                  default:                                  // invalid NSC5
                     {
                        encoded = null;
                        break;
                     }
               }
            }
            catch
            {
               encoded = null;
            }
         }
         return (encoded);
      }
      #endregion


   }
}
