﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class SwitchVrecMap
   {
      public int Low { get; set; }
      public int High { get; set; }
      public int Record { get; set; }
   }
}
