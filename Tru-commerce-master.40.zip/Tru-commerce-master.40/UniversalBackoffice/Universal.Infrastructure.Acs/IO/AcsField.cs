﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class AcsField
   {
      public string Name { get; set; }
      public string Ubo { get; set; }
      public string Label { get; set; }
      public string Type { get; set; }
      public string UboType { get; set; }
      public bool Key { get; set; }
      public int Offset { get; set; }
      public int Length { get; set; }
      public int ArrayLength { get; set; }
   }
}
