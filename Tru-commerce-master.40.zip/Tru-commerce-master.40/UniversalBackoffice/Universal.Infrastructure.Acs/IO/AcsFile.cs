﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class AcsFile
   {
      public string Name { get; set; }
      public int Max { get; set; }
      public SwitchingInfo SwitchInfo = null;
      public List<AcsRecord> Records = new List<AcsRecord>();
   }

}
