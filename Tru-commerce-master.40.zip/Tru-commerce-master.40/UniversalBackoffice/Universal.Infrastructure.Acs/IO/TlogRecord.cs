﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class TlogRecord
   {
      public string Name { get; set; }
      public string Identifier { get; set; }
      public bool Header { get; set; }
      public int Length { get; set; }

      public List<AcsField> Fields = new List<AcsField>();
   }
}
