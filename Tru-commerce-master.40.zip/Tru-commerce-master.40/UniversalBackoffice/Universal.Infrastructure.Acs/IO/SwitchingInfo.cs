﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class SwitchingInfo
   {
      public bool RecordSwitched { get; set; }
      public int SwitchField { get; set; }
      public List<SwitchVrecMap> Mappings = new List<SwitchVrecMap>();
      public void LoadInf(string InfDir, string IFile)
      {
         string infFile = InfDir + @"\" + IFile + ".inf";
         if (File.Exists(infFile))
         {
            using (StreamReader sr = new StreamReader(infFile))
            {
               string line = null;
               char[] seperator = { ' ' };
               while ((line = sr.ReadLine()) != null)
               {
                  if (line.StartsWith("FILE"))
                  {
                     if (IFile != line.Split(seperator, StringSplitOptions.RemoveEmptyEntries)[1])
                     {
                        RecordSwitched = false;
                        break;
                     }
                  }
                  if (line.StartsWith("#DATA"))
                  {
                     string[] entries = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                     if (entries.Count() == 3 && entries[1] == "R_SWITCH")
                     {
                        SwitchField = Convert.ToInt32(entries[2]);
                     }
                     if (entries.Count() == 5 && entries[1] == "VREC_MAP")
                     {
                        SwitchVrecMap map = new SwitchVrecMap();
                        map.Low = Convert.ToInt32(entries[2]);
                        map.High = Convert.ToInt32(entries[3]);
                        map.Record = Convert.ToInt32(entries[4]);
                        Mappings.Add(map);
                     }
                  }
               }
            }
         }
      }
   }
}
