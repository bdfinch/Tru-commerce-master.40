
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;


namespace Universal.Infrastructure.Acs.IO
{
   public delegate void TmsErrorEventHandler(object sender);

   #region exceptions
   public class TmsException : Exception
   {
      public TmsException()
      {
      }

      public TmsException(string message)
          : base(message)
      {
      }

      public TmsException(string message, Exception inner)
          : base(message, inner)
      {
      }
   }
   #endregion
   public class Tms : IDisposable
   {
      private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
      public static event TmsErrorEventHandler TmsErrorEvent;
      /// <summary>
      /// Structure of the init IOA.  Must match define in tmsapi.h
      /// </summary>
      bool AlreadyDisposed = false;
      private bool _Locking = false;
      /// <summary>
      /// Set to to true by sucessful read lock.  Unset be write update and unlock. 
      /// </summary>
      public bool Locking
      {
         get { return _Locking; }
         set { _Locking = value; }
      }

      public static List<short> WhiteListedErrors = null;


      const int SET_PIPE_READER = 0x1111;
      const int SET_PIPE_OVERRIDE_READER = 0x1112;
      const int SET_PIPE_NOWRITE = 0x2222;
      const int SET_PIPE_WRITEOK = 0x4444;
      public bool First = true;
      Byte[] FindBuffer;
      Byte[] dataBuffer;
      public GDBIOA_ISAM isam = new GDBIOA_ISAM();
      public GDBIOA ioa;


      [DllImport("tmsif32.dll", CharSet = CharSet.Ansi)]
      public static extern short gbase(ref GDBIOA ioa);


      /// <summary>
      /// Init with tms32
      /// </summary>
      /// <param name="Node">Node ID tms returned</param>
      /// <param name="Group">Group ID tms returned</param>
      /// <returns>TMS error</returns>
      public static short Init(ref int Node, ref int Group)
      {
         short rc = 0;
         GDBIOA ioa = new GDBIOA();
         GDBIOA_INIT initioa = new GDBIOA_INIT();

         ioa.buflen = (short)System.Runtime.InteropServices.Marshal.SizeOf(initioa);
         ioa.datalen = (short)System.Runtime.InteropServices.Marshal.SizeOf(initioa);
         ioa.buffer = Marshal.AllocCoTaskMem(ioa.datalen);
         ioa.request = (int)RequestType.IN;
         ioa.apptype = 7;
         ioa.signature = 0x5a39;
         rc = gbase(ref ioa);

         byte[] byteRepresentationOfSet = new byte[ioa.buflen];
         Marshal.Copy(ioa.buffer, byteRepresentationOfSet, 0, ioa.datalen);
         Marshal.FreeCoTaskMem(ioa.buffer);
         object o = (object)initioa;
         ByteArrayToStructure(byteRepresentationOfSet, ref o);
         initioa = (GDBIOA_INIT)o;
         Node = initioa.node;
         Group = initioa.group;

         WhiteListedErrors = new List<short>();
         WhiteListedErrors.Add((short)Errors.EF);
         WhiteListedErrors.Add((short)Errors.OK);
         WhiteListedErrors.Add((short)Errors.TO);
         WhiteListedErrors.Add((short)Errors.FA);

         return (rc);

      }
      /// <summary>
      /// Init with tms32
      /// </summary>
      /// <returns>TMS error</returns>
      public static short Init()
      {
         int Node = 0;
         int Group = 0;
         return (Init(ref Node, ref Group));
      }
      /// <summary>
      /// Terminate TMS connection
      /// </summary>
      /// <returns>TMS Error</returns>
      public static short Term()
      {
         short rc = 0;
         GDBIOA initioa = new GDBIOA();
         initioa.buflen = 20;
         initioa.datalen = 20;
         initioa.request = (short)RequestType.TM;
         initioa.buffer = Marshal.AllocCoTaskMem(20);
         initioa.apptype = 7;
         initioa.signature = 0x5a39;
         rc = gbase(ref initioa);
         Marshal.FreeCoTaskMem(initioa.buffer);
         return (rc);
      }
      /// <summary>
      /// Convert the specified structure into a byte array so it may be sent to unmanaged code.
      /// </summary>
      /// <param name="obj">Structure to convert</param>
      /// <returns>byte array representation of the structure</returns>
      public static byte[] StructureToByteArray(object obj)
      {
         int len = Marshal.SizeOf(obj);
         byte[] arr = new byte[len];
         IntPtr ptr = Marshal.AllocHGlobal(len);
         Marshal.StructureToPtr(obj, ptr, true);
         Marshal.Copy(ptr, arr, 0, len);
         Marshal.FreeHGlobal(ptr);
         return arr;
      }
      /// <summary>
      /// Convert a byte array to a structure for use in managed code
      /// </summary>
      /// <param name="bytearray">Byte array to convert to structure</param>
      /// <param name="obj">Structure populated by byte array data</param>
      public static void ByteArrayToStructure(byte[] bytearray, ref object obj)
      {
         int len = Marshal.SizeOf(obj);
         IntPtr i = Marshal.AllocHGlobal(len);
         Marshal.Copy(bytearray, 0, i, len);
         obj = Marshal.PtrToStructure(i, obj.GetType());
         Marshal.FreeHGlobal(i);
      }
      private string FileName { get; set; }
      /// <summary>
      /// TMS construtor
      /// </summary>
      public Tms()
      {
         ioa = new GDBIOA();
         ioa.buflen = 20;
         ioa.datalen = 20;
         ioa.request = (int)RequestType.IN;
         dataBuffer = new Byte[1024];
         ioa.buffer = Marshal.AllocCoTaskMem(1024);
         FileName = "";

      }
      /// <summary>
      /// Main IO routine acces to tms32.  Everything goes through gbase to we only have to wrap one API
      /// </summary>
      /// <returns></returns>
      private short Io()
      {
         short tmsError = 0;
         ioa.apptype = 7;
         ioa.signature = 0x5a39;
         tmsError = gbase(ref ioa);
         // add throw errors here
         if (tmsError == 0)
         {
            Marshal.Copy(ioa.buffer, dataBuffer, 0, 1024);
         }
         else
         {
            if (!WhiteListedErrors.Contains(tmsError))
            {
               //throw new TmsException("Error " + tmsError + " on file " + FileName);
               TmsErrorEvent(this);
            }
         }
         return (tmsError);
      }
      /// <summary>
      /// Set caller to the reader of the pipe
      /// </summary>
      /// <returns>TMS error</returns>
      public short SetReader()
      {
         short tmsError = 0;
         GDBIOA_SETS set = new GDBIOA_SETS();
         set.mode = SET_PIPE_READER;
         ioa.request = (short)RequestType.ST;
         ioa.buflen = (short)System.Runtime.InteropServices.Marshal.SizeOf(set);
         ioa.datalen = (short)System.Runtime.InteropServices.Marshal.SizeOf(set);
         byte[] byteRepresentationOfSet = StructureToByteArray(set);
         Marshal.Copy(byteRepresentationOfSet, 0, ioa.buffer, ioa.buflen);
         tmsError = (short)Io();
         return (tmsError);
      }
      /// <summary>
      /// ISAM get next using specified secondary key
      /// </summary>
      /// <param name="Record">byte representation of the record to read</param>
      /// <param name="key">the isam key index to use</param>
      /// <returns>TMS error</returns>
      public short GetNext(byte[] Record, short key)
      {
         short rc = 0;
         short isam_length = (short)System.Runtime.InteropServices.Marshal.SizeOf(isam);
         ioa.request = (short)RequestType.GN;
         if (First == true)
         {
            ioa.request = (short)RequestType.GF;
            First = false;
         }
         isam.index_number = key;
         isam.type = 1;
         byte[] GetBuf = new byte[isam_length + Record.Length];
         byte[] isamInBytes = StructureToByteArray(isam);
         Array.Copy(isamInBytes, GetBuf, isamInBytes.Length);
         Array.Copy(Record, 0, GetBuf, isamInBytes.Length, Record.Length);

         ioa.buflen = (short)GetBuf.Length;
         ioa.datalen = (short)GetBuf.Length;
         Marshal.Copy(GetBuf, 0, ioa.buffer, GetBuf.Length);
         rc = Io();
         if (rc == 0)
         {
            Marshal.Copy(ioa.buffer, GetBuf, 0, GetBuf.Length);
            Array.Copy(GetBuf, isamInBytes.Length, Record, 0, Record.Length);
         }
         return (rc);
      }
      /// <summary>
      /// Get Next ISAM/KEYED record
      /// </summary>
      /// <param name="Record">byte representation of the record to read</param>
      /// <returns>TMS error</returns>
      public short GetNext(byte[] Record)
      {
         short rc = 0;
         ioa.request = (short)RequestType.GN;
         if (First == true)
         {
            ioa.request = (short)RequestType.GF;
            FindBuffer = new byte[42];
            First = false;
         }
         byte[] GetBuf = new byte[Record.Length + FindBuffer.Length];
         Array.Copy(FindBuffer, GetBuf, FindBuffer.Length);
         ioa.buflen = (short)(Record.Length + FindBuffer.Length);
         ioa.datalen = (short)(Record.Length);
         Marshal.Copy(GetBuf, 0, ioa.buffer, GetBuf.Length);
         rc = Io();
         if (rc == 0)
         {
            Marshal.Copy(ioa.buffer, GetBuf, 0, FindBuffer.Length + Record.Length);
            Array.Copy(GetBuf, FindBuffer, FindBuffer.Length);
            Array.Copy(GetBuf, FindBuffer.Length, Record, 0, Record.Length);
         }
         return (rc);
      }
      /// <summary>
      /// Seek to the offset of a RANDOM file
      /// </summary>
      /// <param name="offset">Offset to seek to</param>
      /// <returns>TMS error</returns>
      public short Seek(int offset)
      {
         short rc = 0;
         byte[] pos = new byte[262];
         ioa.request = (short)RequestType.SP;
         ioa.buflen = (short)pos.Length;
         ioa.datalen = (short)pos.Length;

         Array.Copy(BitConverter.GetBytes(offset), 0, pos, 2, 4);
         Marshal.Copy(pos, 0, ioa.buffer, pos.Length);
         rc = Io();
         return (rc);
      }
      /// <summary>
      /// Report current location in RANDOM file
      /// </summary>
      /// <param name="offset">location in RANDOM file</param>
      /// <returns>TMS Error</returns>
      public short Tell(out int offset)
      {
         short rc = 0;
         byte[] pos = new byte[262];
         offset = 0;
         ioa.request = (short)RequestType.GP;
         ioa.buflen = (short)pos.Length;
         ioa.datalen = (short)pos.Length;

         //GDBIOA_POS pos = new GDBIOA_POS();
         Marshal.Copy(pos, 0, ioa.buffer, pos.Length);
         rc = Io();
         if (rc == 0)
         {
            offset = BitConverter.ToInt32(dataBuffer, 2);
         }
         return (rc);
      }
      /// <summary>
      /// Report the size of a TMS file
      /// </summary>
      /// <param name="size">size of the file</param>
      /// <returns>TMS Error</returns>
      public short Size(out int size)
      {
         short rc = 0;
         byte[] sizeIO = new byte[4];
         size = 0;
         ioa.request = (short)RequestType.SZ;
         ioa.buflen = (short)sizeIO.Length;
         ioa.datalen = (short)sizeIO.Length;

         //GDBIOA_POS pos = new GDBIOA_POS();
         Marshal.Copy(sizeIO, 0, ioa.buffer, sizeIO.Length);
         rc = Io();
         if (rc == 0)
         {
            size = BitConverter.ToInt32(dataBuffer, 0);
         }
         return (rc);
      }
      /// <summary>
      /// Read a TMS record
      /// </summary>
      /// <param name="Record">byte representation of the record to read</param>
      /// <returns>TMS error</returns>
      public short Read(byte[] Record)
      {
         short rc = 0;
         ioa.buflen = (short)Record.Length;
         ioa.datalen = (short)Record.Length;
         if (Locking == true)
         {
            ioa.request = (short)RequestType.RL;
         }
         else
         {
            ioa.request = (short)RequestType.RD;
         }

         Marshal.Copy(Record, 0, ioa.buffer, Record.Length);
         rc = Io();
         if (rc == 0)
         {
            Array.Copy(dataBuffer, Record, Record.Length);
         }
         return (rc);
      }
      /// <summary>
      /// Read a TMS record
      /// </summary>
      /// <param name="Record">byte representation of the record to read</param>
      /// <param name="Lock">If true lock record on sucessful read.  If false do not lock record.</param>
      /// <returns>TMS error</returns>
      public short Read(byte[] Record, bool Lock)
      {
         short rc = 0;
         Locking = Lock;
         rc = Read(Record);
         if (rc != 0)
         {
            Locking = false;
         }
         return (rc);

      }
      /// <summary>
      /// Write a TMS record.  If the record was lock a write unlock is done.
      /// </summary>
      /// <param name="Record">byte representation of the record to write</param>
      /// <returns>TMS Error</returns>
      public short Write(byte[] Record, bool Immediate)
      {
         short rc = 0;
         ioa.buflen = (short)Record.Length;
         ioa.datalen = (short)Record.Length;
         if (Locking == true)
         {
            ioa.request = (int)RequestType.WU;
            if (Immediate)
            {
               ioa.request = (int)RequestType.IU;
            }
            Locking = false;  // this must be set on every call
         }
         else
         {
            ioa.request = (int)RequestType.WR;
            if (Immediate)
            {
               ioa.request = (int)RequestType.WI;
            }
         }
         Marshal.Copy(Record, 0, ioa.buffer, Record.Length);
         rc = Io();
         return (rc);
      }
      /// <summary>
      /// Write a TMS record.  If the record was lock a write unlock is done.
      /// </summary>
      /// <param name="Record">byte representation of the record to write</param>
      /// <returns>TMS Error</returns>
      public short Write(byte[] Record)
      {
         return (Write(Record, false));
      }
      /// <summary>
      /// Delete a TMS record
      /// </summary>
      /// <param name="Record">byte representation of the record to delete</param>
      /// <returns>TMS Error</returns>
      public short Delete(byte[] Record)
      {
         return (Delete(Record, false));
      }
      /// <summary>
      /// Delete a TMS record
      /// </summary>
      /// <param name="Record">byte representation of the record to delete</param>
      /// <returns>TMS Error</returns>
      public short Delete(byte[] Record, bool Immediate)
      {
         short rc = 0;
         ioa.buflen = (short)Record.Length;
         ioa.datalen = (short)Record.Length;
         ioa.request = (short)RequestType.DL;
         if (Immediate)
         {
            ioa.request = (short)RequestType.DI;
         }
         Marshal.Copy(Record, 0, ioa.buffer, Record.Length);
         rc = Io();
         Locking = false;
         return (rc);
      }
      /// <summary>
      /// Unlock a locked TMS record
      /// </summary>
      /// <param name="Record">byte representation of the record to unlock</param>
      /// <returns>TMS Error</returns>
      public short Unlock(byte[] Record)
      {
         short rc = 0;
         ioa.buflen = (short)Record.Length;
         ioa.datalen = (short)Record.Length;
         ioa.request = (short)RequestType.UL;
         Marshal.Copy(Record, 0, ioa.buffer, Record.Length);
         rc = Io();
         Locking = false;
         return (rc);
      }
      /// <summary>
      /// Write to a TMS pipe
      /// </summary>
      /// <param name="Record">byte representation of the record to write</param>
      /// <param name="FileNum">The pipe instance to write to.</param>
      /// <returns>TMS Error</returns>
      public short WritePipe(byte[] Record, ushort FileNum)
      {
         ioa.filenum = FileNum;
         return (Write(Record));
      }

      /// <summary>
      /// Create a TMS file.
      /// </summary>
      /// <param name="File">Internal filename of file to create.</param>
      /// <returns>TMS Error</returns>
      public short Create(string File)
      {
         return (Create(File, 0));
      }

      /// <summary>
      /// Create a TMS file
      /// </summary>
      /// <param name="File">Internal filename of file to create.</param>
      /// <param name="num">The multifile extension(.000 - .999)</param>
      /// <returns>TMS Error</returns>
      public short Create(string File, ushort num)
      {
         // this create only allows caller to create the file of the default size
         short rc = 0;
         byte[] openIO = new byte[7];
         ioa.buflen = (short)openIO.Length;
         ioa.datalen = (short)openIO.Length;
         ioa.filenum = num;
         ioa.request = (short)RequestType.CF;
         byte[] asciiString = Encoding.ASCII.GetBytes(File);
         asciiString.CopyTo(openIO, 1);
         Marshal.Copy(openIO, 0, ioa.buffer, openIO.Length);
         rc = Io();
         return (rc);

      }
      /// <summary>
      /// Creat a TMS ISAM file with specified alternat key defines
      /// </summary>
      /// <param name="File">Internal filename of file to create.</param>
      /// <param name="num">The multifile extension(.000 - .999)</param>
      /// <param name="numkeys">The number of secondary keys</param>
      /// <param name="keydefs">The key definition array</param>
      /// <returns>TMS Error</returns>
      public short Create(string File, ushort num, ushort numkeys, short[] keydefs)
      {
         short rc = 0;
         GDBIOA_CREATE_WITH_KEYS create_ioa = new GDBIOA_CREATE_WITH_KEYS();
         create_ioa.filesize = numkeys;
         create_ioa.keys = new short[30];
         for (int i = 0; i < keydefs.Length; i++)
         {
            create_ioa.keys[i] = keydefs[i];
         }

         ioa.buflen = (short)System.Runtime.InteropServices.Marshal.SizeOf(create_ioa);
         ioa.datalen = (short)System.Runtime.InteropServices.Marshal.SizeOf(create_ioa);
         ioa.filenum = num;

         ioa.request = (short)RequestType.CF;
         create_ioa.name = Encoding.ASCII.GetBytes(File);
         byte[] byteRepresentationOfCreate = StructureToByteArray(create_ioa);
         Marshal.Copy(byteRepresentationOfCreate, 0, ioa.buffer, ioa.buflen);
         rc = Io();
         return (rc);

      }
      /// <summary>
      /// Open a TMS file or pipe.
      /// </summary>
      /// <param name="FileOrPipe">Internal filename of file/pipe to open.</param>
      /// <returns>TMS Error</returns>
      public short Open(string FileOrPipe)
      {
         return (Open(FileOrPipe, 0, false));
      }
      /// <summary>
      /// Open a TMS file.
      /// </summary>
      /// <param name="File">Internal filename of file to create.</param>
      /// <param name="Abort">Abort File Distribution</param>
      /// <returns>TMS Error</returns>
      public short Open(string File, bool Abort)
      {
         short rc = 0;
         rc = Open(File, 0, Abort);
         return (rc);
      }
      /// <summary>
      /// Open a TMS file
      /// </summary>
      /// <param name="file">Internal filename of file to open.</param>
      /// <param name="num">The multifile extension(.000 - .999)</param>
      /// <param name="Abort">Abort File Distribution</param>
      /// <returns>TMS Error</returns>
      public short Open(string file, ushort num, bool Abort)
      {
         short rc = 0;
         byte[] openIO = new byte[7];
         ioa.buflen = (short)openIO.Length;
         ioa.datalen = (short)openIO.Length;
         ioa.filenum = num;
         ioa.request = (short)RequestType.OP;
         if (Abort)
         {
            ioa.request = (short)RequestType.OA;
         }
         byte[] asciiString = Encoding.ASCII.GetBytes(file);
         asciiString.CopyTo(openIO, 1);
         Marshal.Copy(openIO, 0, ioa.buffer, openIO.Length);
         rc = Io();
         return (rc);
      }
      public short Open(string file, ushort num, bool Abort, bool Create)
      {
         short rc = 0;
         byte[] openIO = new byte[7];
         ioa.buflen = (short)openIO.Length;
         ioa.datalen = (short)openIO.Length;
         ioa.filenum = num;
         ioa.request = (short)RequestType.OP;
         if (Abort)
         {
            ioa.request = (short)RequestType.OA;
         }
         byte[] asciiString = Encoding.ASCII.GetBytes(file);
         asciiString.CopyTo(openIO, 1);
         Marshal.Copy(openIO, 0, ioa.buffer, openIO.Length);
         rc = Io();
         if ((rc == (short)Tms.Errors.FA) && Create)
         {
            rc = this.Create(file, num);
         }
         return (rc);
      }
      /// <summary>
      /// Close a TMS file
      /// </summary>
      /// <returns>TMS Error</returns>
      public short Close()
      {
         short rc = 0;
         byte[] openIO = new byte[7];
         ioa.buflen = (short)openIO.Length;
         ioa.datalen = (short)openIO.Length;
         ioa.request = (short)RequestType.CL;
         rc = Io();
         return (rc);
      }
      [StructLayout(LayoutKind.Sequential, Pack = 2)]
      public struct GDBIOA_INIT
      {
         public ushort node;
         public byte appl;
         public byte scrn_group;
         public ushort group;
      }
      /// <summary>
      /// Structure of the GDBIOA_CRTE IOA.  Must match define in tmsapi.h
      /// </summary>
      [StructLayout(LayoutKind.Sequential, Pack = 2)]
      public struct GDBIOA_CREATE_WITH_KEYS
      {
         public byte exclusive;
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
         public byte[] name;
         public byte pad;
         public uint filesize;
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
         public short[] keys;

      }
      /// <summary>
      /// Structure of the GDBIOA_ISAM IOA.  Must match define in tmsapi.h
      /// </summary>
      [StructLayout(LayoutKind.Sequential, Pack = 2)]
      public struct GDBIOA_ISAM
      {
         public int record_offset;
         public short index_number;
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
         public byte[] reserved;//sizeof(GDBSRCH)*MAX_EXT_FILES - 1;
         public ushort offset;                            /* offset of search field            */
         public ushort length;                            /* length of search field            */
         public ushort type;
      }
      /// <summary>
      /// Structure of the GDBIOA IOA.  Must match define in tmsapi.h
      /// </summary>
      [StructLayout(LayoutKind.Sequential, Pack = 2)]
      public struct GDBIOA
      {
         public ushort signature;
         public byte application;
         public byte scrn_group;
         public byte apptype;
         public byte avail1;
         public short retcode;
         public short request;
         public ushort context;
         public short rectype;

         public short buflen;
         public IntPtr buffer;
         public short datalen;
         public short retlen;
         public byte sync;
         public byte avail2;
         public ushort filenum;
         public ushort handle;
         public uint seqnum;
         public int semaphore;
         public uint seq_file_pos;
         public short device_err;
      }
      /// <summary>
      /// Structure of the GDBIOA_POS IOA.  Must match define in tmsapi.h
      /// </summary>
      [StructLayout(LayoutKind.Sequential, Pack = 2)]
      public struct GDBIOA_POS
      {
         public ushort state;
         public int field;
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
         public byte[] key;
      }
      /// <summary>
      /// Structure of the GDBIOA_SETS IOA.  Must match define in tmsapi.h
      /// </summary>
      [StructLayout(LayoutKind.Sequential, Pack = 2)]
      public struct GDBIOA_SETS
      {
         public byte reset;
         public byte pad1;
         public ushort mode;
         public ushort position;
         public ushort colour;
         public ushort style;
         public short cursor_x;
         public short cursor_y;
         public byte pos_cursor;
         public byte pad2;
      }
      /// <summary>
      /// Structure of the GDBIOA_OPEN IOA.  Must match define in tmsapi.h
      /// </summary>
      [StructLayout(LayoutKind.Sequential, Pack = 2)]
      public struct GDBIOA_OPEN
      {
         byte exclusive;
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
         byte[] name;
      }
      /// <summary>
      /// Request type available.
      /// </summary>
      enum RequestType : short
      {
         CF = 17987, // GDBREQ_CF create file 
         DL = 19524, // GDBREQ_DL delete record
         DI = 18756, // GDBREQ_DL delete immediate record
         OP = 20559, // GDBREQ_OP open 
         OA = 16719, // GDBREQ_OA open and abort distribution
         CL = 19523, // GDBREQ_CL close
         IN = 20041, // GDBREQ_IN init
         TM = 19796, // GDBREQ_TM term
         RD = 17490, // GDBREQ_RD read
         RL = 19538, // GDBREQ_RL read lock
         WR = 21079, // GDBREQ_WR write
         WI = 18775, // GDBREQ_WI write immediate
         WU = 21847, // GDBREQ_WU write unlock
         IU = 21833, // GDBREQ_UI write immediate unlock
         UL = 19541, // GDBREQ_UL unlock record
         GF = 17991, // GDBREQ_GF get first
         GN = 20039, // GDBREQ_GN get next
         SP = 20563, // GDBREQ_SP set position for reading random files
         GP = 20551, // GDBREQ_GP get postion ie tell for random files
         SZ = 23123, // GDBREQ_SZ get file size
         GT = 21575, // GDBREQ_GT Get Status pipe command
         ST = 21587, // GDBREQ_ST Set state pipe command
         WT = 21591 // GDBREQ_WT wait for time
      };
      /// <summary>
      /// Error transalated.  Subset of available errors.
      /// </summary>
      public enum Errors : short
      {
         OK = 0, // end of file
         FA = 16710, // file absent
         EF = 17989, // end of file
         IL = 19529, // illegal
         LK = 19276, // record Locked
         ML = 19533, // already locked by same appl
         NL = 19534, // Not Loaded
         DS = 21316, // DSL Not Loaded
         NS = 21326, // DSL Not Loaded
         NP = 20558, // DSL Not Loaded
         NF = 17998, // not found 
         TO = 20308, // timeout
         FL = 19526, // fault detected
         LF = 17996  // LAN failure
      }


      #region IDisposable Members

      public void Dispose()
      {
         Dispose(false);
      }
      public void Dispose(bool GarbageCollected)
      {
         if (AlreadyDisposed == false)
         {
            Marshal.FreeCoTaskMem(this.ioa.buffer); // BDF should this be after next if
            if (GarbageCollected == false)
            {
               GC.SuppressFinalize(this);
            }
            AlreadyDisposed = true;
         }
      }
      ~Tms()
      {
         this.Dispose(true);
      }

      #endregion
   }
}


