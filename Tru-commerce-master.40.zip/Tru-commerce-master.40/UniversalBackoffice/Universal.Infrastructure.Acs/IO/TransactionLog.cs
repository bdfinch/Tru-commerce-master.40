﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class TransactionLog
   {
      public List<TlogRecord> Records = new List<TlogRecord>();
   }
}
