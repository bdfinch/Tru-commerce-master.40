﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;
using System.Globalization;
using Universal.Infrastructure.Acs;

// fix class to classes in opauth


namespace Universal.Infrastructure.Acs.IO
{
   public class FileDictionary
   {
      private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

      public List<AcsFile> Files = new List<AcsFile>();
      public TransactionLog Tlog = new TransactionLog();
      public dynamic ToDynamic(AcsRecord Record)
      {
         dynamic record = new ExpandoObject();
         var dictionary = (IDictionary<string, object>)record;

         foreach (AcsField ff in Record.Fields)
         {
            if (ff.Type == "S3" || ff.Type == "CH")
            {
               dictionary.Add(ff.Name, "");
            }
            else
            {
               dictionary.Add(ff.Name, 0);
            }
         }
         return (record);
      }
      public AcsRecord Record(AcsFile File, byte[] binary)
      {
         int switcher = 0;
         if (File.SwitchInfo != null)
         {
            // figure out switching
            switcher = (int)AcsIO.BinaryTo(binary, File.Records[0].Fields[File.SwitchInfo.SwitchField]);
            if (File.SwitchInfo.RecordSwitched == false)
            {
               foreach (SwitchVrecMap s in File.SwitchInfo.Mappings)
               {
                  if (s.Low <= switcher && s.High >= switcher)
                  {
                     switcher = s.Record;
                     break;
                  }
               }
            }
            List<AcsRecord> recs = File.Records.Where(s => s.Number == switcher).ToList();
            if (recs.Count > 0)
            {
               return (recs[0]);
            }
         }

         return (File.Records[0]);
      }
 
      public dynamic ToDynamic(AcsFile File, byte[] binary)
      {
         dynamic record = new ExpandoObject();
         var dictionary = (IDictionary<string, object>)record;
         int switcher = 0;
         if (File.SwitchInfo != null)
         {
            // figure out switching
            switcher = (int)AcsIO.BinaryTo(binary, File.Records[0].Fields[File.SwitchInfo.SwitchField]);
            if (File.SwitchInfo.RecordSwitched == false)
            {
               foreach (SwitchVrecMap s in File.SwitchInfo.Mappings)
               {
                  if (s.Low <= switcher && s.High >= switcher)
                  {
                     switcher = s.Record;
                     break;
                  }
               }
            }
         }

         List<AcsRecord> recs = File.Records.Where(s => s.Number == switcher).ToList();
         if (recs.Count > 0)
         {
            AcsRecord rec = recs[0];
            dictionary.Add(rec.Name,ToDynamic(rec, binary));
            return (dictionary);
         }
         return (null);
      }
      //dynamic RecordName = new ExpandoObject();
      //var dictionary = (IDictionary<string, object>)RecordName;
      ////return (ToDynamic(Record, binary, 0));
      //return (RecordName);

      public dynamic ToDynamic(AcsRecord Record, byte[] binary)
      {
         return (ToDynamic(Record,binary,0));
      }
      public dynamic ToDynamic(AcsRecord Record, byte[] binary, int offset)
      {
         dynamic record = new ExpandoObject();
         var dictionary = (IDictionary<string, object>)record;

         int count=0;
         while (count < Record.Fields.Count())
         {
            AcsField ff = Record.Fields[count];
            if (ff.ArrayLength > 0)
            {
               int acount = 0;
               List<object> array = new List<object>();
               while (acount < ff.ArrayLength)
               {
                  array.Add(AcsIO.BinaryTo(binary, ff, offset));
                  offset += ff.Length;
                  acount++;
               }
               dictionary.Add(ff.Name, array);
               offset = 0;
            }
            else
            {
               dictionary.Add(ff.Name, AcsIO.BinaryTo(binary, ff, offset));
            }
            count++;
         }
         return (record);
      }
      private void CreateFiles(List<FileInfo> fiArr,string Bgf, string Inf)
      {
         int reccount = 0;

         string bgfPath = Bgf;
         string infPath = Inf;
         //string tlogBgfPath = @"c:\acs\server\bgf\HighOME";
         TextInfo info = CultureInfo.CurrentCulture.TextInfo;

         #region acs files
         log.DebugFormat("Processing bgfs bgfdir={0} infdir = {1}",bgfPath,infPath);
         int filecount = 0;
         foreach (FileInfo file in fiArr)
         {
            if (file.Length < 100)
            {
               continue;
            }
            try
            {
               log.DebugFormat("Processing file={0}", file.Name);
               using (StreamReader sr = new StreamReader(bgfPath + @"\" + file.Name))
               {
                  string line = null;
                  string fileName = null;
                  char[] seperator = { ' ' };
                  reccount = 0;
                  SwitchingInfo switchingInfo = new SwitchingInfo();
                  string ArrayName = "";
                  int ArrayDim = 0;
                  while ((line = sr.ReadLine()) != null)
                  {
                     log.DebugFormat("Processing line={0}", line);
                     line = line.ToUpper();

                     if (line.StartsWith("FILE"))
                     {
                        ArrayName = "";
                        ArrayDim = 0;
                        if (line.Contains("VIRTUAL"))
                        {
                           break;
                        }
                        else
                        {
                           AcsFile f = new AcsFile();
                           f.Name = fileName = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries)[1];
                           f.Records = new List<AcsRecord>();
                           Files.Add(f);
                           filecount++;
                           continue;
                        }
                     }
                     if (line.StartsWith("RECORD"))
                     {
                        ArrayName = "";
                        ArrayDim = 0;
                        if (Files[filecount - 1].Records.Count() == 1)
                        {
                           if (switchingInfo.RecordSwitched == false)
                           {
                              switchingInfo.LoadInf(infPath, Files[filecount - 1].Name);
                           }
                           Files[filecount - 1].SwitchInfo = switchingInfo;
                        }
                        AcsRecord rec = new AcsRecord();
                        string[] entries = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                        if (entries.Count() == 4)
                        {
                           rec.Name = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries)[3];
                           rec.Number = Convert.ToInt32(line.Split(seperator, StringSplitOptions.RemoveEmptyEntries)[1]);
                           rec.Length = Convert.ToInt32(line.Split(seperator, StringSplitOptions.RemoveEmptyEntries)[2]);
                           rec.Mappings = new List<int>();
                           if (rec.Length > Files[filecount - 1].Max)
                           {
                              Files[filecount - 1].Max = rec.Length;
                           }
                           Files[filecount - 1].Records.Add(rec);
                           reccount++;
                        }
                        else
                        {
                           log.WarnFormat("bad record definition in bgf file {0}", fileName);
                        }
                     }
                     if (line.StartsWith("FIELD"))
                     {
                        string[] entries = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                        if (entries.Count() >= 6)
                        {
                           if (ArrayName != "")
                           {
                              string thisName = entries[2].ToLower();
                              thisName = thisName.Remove(thisName.Length - ArrayDim, ArrayDim);
                              if (ArrayName == thisName)
                              {
                                 Files[filecount - 1].Records[reccount - 1].Fields.Last().ArrayLength++;
                                 continue;
                              }
                              else
                              {
                                 ArrayName = "";
                              }
                           }
                           AcsField f = new AcsField();

                           f.Name = entries[2].ToLower();


                           f.ArrayLength = 0;
                           if (f.Name.EndsWith("001"))
                           {
                              f.Name = ArrayName = f.Name.Replace("001", "");
                              f.ArrayLength = 1;
                              ArrayDim = 3;
                           }
                           if (f.Name.EndsWith("01"))
                           {
                              f.Name = ArrayName = f.Name.Replace("01", "");
                              f.ArrayLength = 1;
                              ArrayDim = 2;
                           }
                           f.Ubo = f.Name;
                           if (f.Name.StartsWith("num_"))
                           {
                              f.Ubo = f.Name.Replace("num_", "") + " Count";
                           }
                           f.Ubo = f.Ubo.Replace("_", " ");
                           f.Label = info.ToTitleCase(f.Ubo) + ":";
                           f.Ubo = info.ToTitleCase(f.Ubo).Replace(" ", string.Empty);

                           f.Type = entries[3];
                           f.Offset = Convert.ToInt32(entries[4]);
                           f.Length = Convert.ToInt32(entries[5]);
                           f.UboType = "int";
                           if (f.Type == "S3" || f.Type == "CH")
                           {
                              f.UboType = "string";
                           }

                           if ((entries.Count() == 7 && entries[6] == "SW") ||
                              (entries.Count() == 8 && entries[7] == "SW"))
                           {
                              switchingInfo.RecordSwitched = true;
                              switchingInfo.SwitchField = Files[filecount - 1].Records[reccount - 1].Fields.Count();
                           }
                           if (entries.Count() >= 7 && entries[6] == "KEY")
                           {
                              f.Key = true;
                           }

                           Files[filecount - 1].Records[reccount - 1].Fields.Add(f);
                        }
                     }
                     if (line.StartsWith("END"))
                     {
                     }
                  }
               }
            }
            catch (Exception e)
            {
               log.Warn("Unable to process file definition for " + file.Name,e );
            }
         }

         #endregion

      }
      private void CreateTlog(string TlogBgf)
      {
         #region tlog
         string tlogBgfPath = TlogBgf;
         DirectoryInfo diT = new DirectoryInfo(tlogBgfPath);
         FileInfo[] fiArrT = diT.GetFiles("*.bgf");
          int filecount;
         log.DebugFormat("Processing {0} tlog bgfs in {1}", fiArrT.Length, tlogBgfPath);
         foreach (FileInfo file in fiArrT)
         {
            log.DebugFormat("Processing file {0}", tlogBgfPath + @"\" + file.Name);
            using (StreamReader sr = new StreamReader(tlogBgfPath + @"\" + file.Name))
            {
               filecount = 0;
               string line = null;
               char[] seperator = { ' ' };
               string ArrayName = "";
               while ((line = sr.ReadLine()) != null)
               {
                  log.DebugFormat("Processing line {0}", line);
                  if (line.StartsWith("FILE"))
                  {
                     ArrayName = "";
                     filecount++;
                     if (line.Contains("VIRTUAL"))
                     {
                        break;
                     }
                     else
                     {
                        continue;
                     }
                  }
                  if (line.StartsWith("RECORD"))
                  {
                     ArrayName = "";
                     TlogRecord rec = new TlogRecord();
                     string[] entries = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                     if (entries.Count() == 4)
                     {
                        string[] name = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries)[3].Split('-');
                        rec.Name = name[0];
                        rec.Identifier = name[1];
                        if (rec.Name == "GTLFST" ||
                           rec.Name == "GTLTBH" ||
                           rec.Name == "GTLTCL" ||
                           rec.Name == "GTLSCL" ||
                           rec.Name == "GTLNOT")
                        {
                           rec.Header = true;
                           rec.Length = 20;
                        }
                        else
                        {
                           rec.Header = false;
                           rec.Length = Convert.ToInt32(line.Split(seperator, StringSplitOptions.RemoveEmptyEntries)[2]);
                        }
                        if (name.Count() == 3)
                        {
                           rec.Identifier += "-" + name[2];
                        }

                        Tlog.Records.Add(rec);
                      }
                     else
                     {
                        log.Warn("bad record definition in TLOG bgf");
                     }
                  }
                  if (line.StartsWith("FIELD"))
                  {

                     string[] entries = line.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                     if (entries.Count() == 6)
                     {
                        if (ArrayName != "")
                        {
                           if (ArrayName == entries[2].ToLower().Substring(0, Math.Min(ArrayName.Length, entries[2].Length)))
                           {
                              Tlog.Records.Last().Fields.Last().ArrayLength++;
                              continue;
                           }
                           else
                           {
                              ArrayName = "";
                           }
                        }
                        AcsField f = new AcsField();
                        f.Name = entries[2].ToLower();
                        if (f.Name.EndsWith("001"))
                        {
                           ArrayName = f.Name.Replace("001", "");
                        }
                        if (f.Name.EndsWith("01"))
                        {
                           ArrayName = f.Name.Replace("01", "");
                        }

                        f.Type = entries[3];
                        f.Offset = Convert.ToInt32(entries[4]);
                        f.Length = Convert.ToInt32(entries[5]);
                        Tlog.Records.Last().Fields.Add(f);

                     }
                  }
                  if (line.StartsWith("END"))
                  {
                  }
               }
            }
         }
         #endregion
      }


      public FileDictionary()
      {
         bool DoTlog = true;
         UniversalConfig config = UniversalConfig.Instance;
         DirectoryInfo di = new DirectoryInfo(config.Config.BgfPath);
         List<FileInfo> fiList = new List<FileInfo>();
 
         if (config.Config.WhiteList.Count > 0)
         {
            // if tlog is not in the white list get out
            if (!config.Config.WhiteList.Contains("TLOG"))
            {
               DoTlog = false;
            }
            foreach (string f in config.Config.WhiteList)
            {
               fiList.AddRange(((FileInfo[])di.GetFiles(f.ToLower() + ".bgf")).ToList());
            }
         }
         if (config.Config.BlackList.Count > 0)
         {
            // if tlog is in the black list get out
            if (config.Config.BlackList.Contains("TLOG"))
            {
               DoTlog = false;
            }
         }
         else
         {
            fiList.AddRange(((FileInfo[])di.GetFiles("*.bgf")).ToList());
            
         }
         if (fiList.Count() > 0)
         {
            CreateFiles(fiList, config.Config.BgfPath, config.Config.InfPath);
         }
         if (DoTlog)
         {
            CreateTlog(config.Config.TlogPath);
         }

      }
   }
}
