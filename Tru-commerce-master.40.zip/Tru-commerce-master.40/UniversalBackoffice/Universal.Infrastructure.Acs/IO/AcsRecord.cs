﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class AcsRecord
   {
      public string Name { get; set; }
      public int Number { get; set; }
      public int Length { get; set; }
      public List<int> Mappings = new List<int>();
      public List<AcsField> Fields = new List<AcsField>();
   }
}
