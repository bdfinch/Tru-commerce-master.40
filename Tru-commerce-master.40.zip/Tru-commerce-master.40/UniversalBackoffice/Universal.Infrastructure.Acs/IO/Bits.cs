﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class Bit
   {
      public string Name { get; set; }
      public Int32 Value { get; set; }
      public string UniversalName { get; set; }
   }
   public class BitField
   {
      public string Name { get; set; }
      public List<Bit> Bits { get; set; }
   }
   public class BitRecord
   {
      public string Name { get; set; }
      public List<BitField> Fields { get; set; }
   }
   public class BitFile
   {
      public string Name { get; set; }
      List<BitRecord> Records { get; set; }
   }
   public class BitMapping
   {
      List<BitFile> Files { get; set; }
   }
}
