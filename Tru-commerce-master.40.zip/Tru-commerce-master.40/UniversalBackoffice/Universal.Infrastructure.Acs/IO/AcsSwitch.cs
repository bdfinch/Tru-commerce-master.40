﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Infrastructure.Acs.IO
{
   public class AcsSwitch
   {
      public string Type { get; set; }
      public int Offset { get; set; }
      public int Length { get; set; }
   }
}
