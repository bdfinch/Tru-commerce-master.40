﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Universal.Core.Interfaces;
using Universal.Core.Model;

namespace Universal.Infrastructure.Acs
{
   public class ProductRepository : IProductRepository
   {
      public void Add(Product p)
      {
         DataManager.Instance.WriteProduct(p);
      }

      public void Edit(Product p)
      {
         DataManager.Instance.WriteProduct(p);
      }

      public IEnumerable<Product> GetProducts()
      {
         throw new NotImplementedException();
      }

      public Product GetProduct(string Id)
      {
          return(DataManager.Instance.GetProduct(Id));
      }

      public void Remove(string ProductID)
      {
         Product p = new Product();
         p.Id = ProductID;
         DataManager.Instance.DeleteProduct(p);
      }
   }
}
