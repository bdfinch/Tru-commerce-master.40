﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Universal.Core.Model;

namespace Universal.Infrastructure.Acs
{
   public class Options
   {
      public List<dynamic> Tenders { get; set; }
      public List<dynamic> Departments { get; set; }
      public List<DepartmentDefintions> DepartmentDefintions { get; set; }
      public dynamic Store { get; set; }
      public dynamic Description { get; set; }
      public Options()
      {
         Tenders = new List<dynamic>();
         Departments = new List<dynamic>();
         DepartmentDefintions = new List<DepartmentDefintions>();
      }
   }
}
