﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Universal.Core.Model;
using Universal.Infrastructure.Acs.IO;

namespace Universal.Infrastructure.Acs
{
   public sealed partial class DataManager
   {
      public TcfInfo GetTfcInfo()
      {
         TcfInfo tcfInfo = new TcfInfo();
         tcfInfo.Period = 1;
         tcfInfo.SequenceCounter = 1;
         tcfInfo.EodInProgress = false;
         lock (_classLock)
         {
            Tms _Tmstcf = new Tms();

            if (_Tmstcf.Open("TCF") == 0)
            { 
               AcsFile file = _Fd.Files.Where(s => s.Name == "TCF").First();
               AcsRecord record = file.Records.Where(r => r.Name.ToUpper() == "STORE_TCF_REC").First();
               byte[] binary = new byte[record.Length];
               AcsField key = record.Fields.Where(n => n.Name == "key_termid").First();
               AcsIO.ManagedToBinary(binary, key, 9999);
               if (_Tmstcf.Read(binary, true) == 0)
               {
                  dynamic tcfStoreRec = _Fd.ToDynamic(record, binary);
                  tcfInfo.Period = tcfStoreRec.period;
                  tcfInfo.SequenceCounter = tcfStoreRec.tlog_seq_count;

                  if (Utils.IsBitSet(tcfStoreRec.flags, 5) || Utils.IsBitSet(tcfStoreRec.flags, 6))
                  {
                     tcfInfo.EodInProgress = true;
                  }
               }
               _Tmstcf.Close();
            }
         }
         return (tcfInfo);
      }
   }
}