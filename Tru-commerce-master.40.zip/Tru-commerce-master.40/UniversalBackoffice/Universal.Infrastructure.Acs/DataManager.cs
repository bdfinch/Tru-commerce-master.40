﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Universal.Infrastructure.Acs.IO;

namespace Universal.Infrastructure.Acs
{
   public sealed partial class DataManager
   {
      private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

      private static Object _classLock = typeof(DataManager);
      private static FileDictionary _Fd;

      private static volatile DataManager instance;

      public FileDictionary Fd { get { return (_Fd); } }

      public bool ExtendedTender { get; set; }
      public bool ExtendedTaxes { get; set; }

      private DataManager()
      {
         this.ExtendedTaxes = false;
         this.ExtendedTender = false;
         short TmsError = Tms.Init();

         if (TmsError == (short)Tms.Errors.OK)
         {
            _Fd = new FileDictionary();
            try
            {
               if (_Fd.Files.Where(s => s.Name == "DEPDEF").First() != null &&
                   _Fd.Files.Where(s => s.Name == "TDROPT").First() != null &&
                   _Fd.Files.Where(s => s.Name == "DESCOP").First() != null &&
                   _Fd.Files.Where(s => s.Name == "STROPT").First() != null)
               {
                  log.InfoFormat("Loading Options");
                  Load();
                  log.InfoFormat("Loading Options Successful");
               }
            }
            catch (Exception e)
            {
               log.Error("Error loading option files.", e);
            }
         }
      }

      public static DataManager Instance
      {
         get
         {
            if (instance == null)
            {
               lock (_classLock)
               {
                  if (instance == null)
                     instance = new DataManager();
               }
            }

            return instance;
         }
      }
      public bool TmsUp()
      {
         lock (_classLock)
         {
            Tms _Tms = new Tms();
            if (_Tms != null)
            {
               _Tms.Open("TCF", false);
               _Tms.Close();
            }
            else
            {
               return (false);
            }
            return (true);
         }
      }
   }
}

