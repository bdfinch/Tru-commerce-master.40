﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace Universal.Infrastructure.Acs
{
    public static class Utils
    {
      public static int NormalizeDecimal(string Decimal, int PlaceAfterDecimal)
      {
         if (Decimal == null)
         {
            return (0);
         }
         if (PlaceAfterDecimal == 0)
         {
            if (Decimal.Contains("."))
            {
               Decimal = Decimal.Remove(Decimal.IndexOf('.'), Decimal.Length - Decimal.IndexOf('.'));
            }
            return (Convert.ToInt32(Decimal));
         }

         string[] broken = Decimal.Split('.');
         if (broken.Count() == 1)
         {
            // no decimal
            if (PlaceAfterDecimal == 1)
            {
               Decimal = Decimal + ".0";
            }
            else
            {
               Decimal = Decimal + ".00";
            }
         
         }
         else if (broken.Count() == 2)
         {
            if(broken[1].Length==1 && PlaceAfterDecimal==2)
            {
               Decimal = Decimal + "0";
            }
         }
         Decimal = Decimal.Replace(".", "");

         return (Convert.ToInt32(Decimal));
      }
      public static DateTime ConvertFromUnixTimestamp(int timestamp)
      {
         DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
         return origin.AddSeconds((double)timestamp);
      }

      public static int ConvertToUnixTimestamp(DateTime date)
      {
         DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
         TimeSpan diff = date.ToUniversalTime() - origin;
         return (int)Math.Floor(diff.TotalSeconds);
      }
      public static List<int> ToIntList(List<object> OList)
      {
         List<int> iList = new List<int>();
         foreach (object o in OList)
         {
            iList.Add((int)o);
         }
         return (iList);
      }
      public static int ZeroBit(int value, int position)
      {
         return value & ~(1 << position);
      }
      /// <summary>
      /// Returns whether the bit at the specified position is set.
      /// </summary>
      /// <typeparam name="T">Any integer type.</typeparam>
      /// <param name="t">The value to check.</param>
      /// <param name="pos">
      /// The position of the bit to check, 0 refers to the least significant bit.
      /// </param>
      /// <returns>true if the specified bit is on, otherwise false.</returns>
      public static bool IsBitSet<T>(this T t, int pos) where T : struct, IConvertible
        {
            bool rc = false;
            var value = t.ToInt64(CultureInfo.CurrentCulture);
            rc=(value & (1 << pos)) != 0;
            return (rc);
        }
      public static int TurnBitOn(int value, int bitToTurnOn)
      {
         return (value | bitToTurnOn);
      }

      public static int TurnBitOff(int value, int bitToTurnOff)
      {
         return (value & ~bitToTurnOff);
      }

      public static int FlipBit(int value, int bitToFlip)
      {
         return (value ^ bitToFlip);
      }

      public static byte[] StringToBcd(string bcdstring)
      {
            ASCIIEncoding ascii = new ASCIIEncoding();
            byte[] asciibcdstring = ascii.GetBytes(Encode(bcdstring));
            byte[] bcd = new byte[asciibcdstring.Length / 2];
            int i = asciibcdstring.Length;

            while (i > 0)
            {
                int j = i / 2;
                bcd[j - 1] = (byte)(asciibcdstring[i - 1] - 0x30);
                i--;
                bcd[j - 1] = ((byte)(bcd[j - 1] + (asciibcdstring[i - 1] - 0x30) * 0x10));
                i--;
            }
            return (bcd);
        }
        public static string Normalize(string UPC)
        {
            if (UPC.Length == 7)
            {
                // get check digit
            }
            return (null);
        }
        #region PadItemCode
        //normalize the PLU code to 13 digits if it's less than 13
        public static string PadItemCode(String item_code)
        {
            string s = item_code;
            if (item_code.Length < 13)
            {
                s = item_code.PadLeft(13, '0');
            }
            return s;
        }
      #endregion

      #region AddCheckDigit
      // check digit algorithm
      //      For instance, the UPC-A barcode for a box of tissues is "036000241457". The last digit is the check digit "7", and if the other numbers are correct then the check digit calculation must produce 7.
      //
      //      1.Add the odd number digits: 0+6+0+2+1+5 = 14
      //      2.Multiply the result by 3: 14 × 3 = 42
      //      3.Add the even number digits: 3+0+0+4+4 = 11
      //      4.Add the two results together: 42 + 11 = 53
      //      5.To calculate the check digit, take the remainder of (53 / 10), which is also known as (53 modulo 10), and subtract from 10. 
      //        Therefore, the check digit value is 7.
        //
        public static string AddCheckDigit(string item_code)
        {
            if (item_code.Length > 13)
            {
                return (item_code);
            }
            ASCIIEncoding encoder = new ASCIIEncoding();
            byte[] bytes = encoder.GetBytes(item_code);
            short oddtotal = 0;
            short eventotal = 0;
            string item = item_code;
            int counter = 0;
            foreach (byte a in bytes)
            {
                counter++;
                byte b = (byte)(a - 0x30);
                if (counter % 2 == 0)
                {
                    eventotal += (short)b;
                }
                else
                {
                    oddtotal += (short)b;
                }
            }
            short cd = (short)(((3 * oddtotal) + eventotal) % 10);
            if (cd > 0)
            {
               cd = (short)(10 - cd);
            }
            item = item_code + cd.ToString();
            return (item);
        }
      #endregion

      #region Encode
      //normalize the PLU code to 14 digits if it's less than 14
        public static string Encode(string Code)
        {
           int EmbeddedPrice = 0;
           return(Encode(Code,ref EmbeddedPrice));
        }
        public static string Encode(string Code, ref int EmbeddedPrice)
        {
            string encoded = Code;
            if (Code == null)
            {
                encoded = Code = "00000000000000";
            }
            if (Code.Length < 15)
            {
                try
                {
                    switch (Code.Length)
                    {
                        // EAN-8 and UPCs of length 12, 13, or 14 already have check digit
                        case 8:
                        case 12:                                  //NSC5 with check digit
                        case 13:
                        case 14:
                            {
                                encoded = Code.PadLeft(14, '0');
                                break;
                            }
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                        case 9:
                        case 10:
                        case 11:
                            {
                                encoded = AddCheckDigit(Code.PadLeft(13, '0'));
                                encoded = encoded.PadLeft(14, '0');
                                break;
                            }
                        default:
                            {
                                encoded = null;
                                break;
                            }
                    }
                }
                catch
                {
                    encoded = null;
                }
            }
            if(encoded.Length==14 && encoded.StartsWith("002"))
            {
               //00260829000005
               string embedded = encoded.Substring(9, 4);
               encoded = encoded.Substring(2, 6).PadRight(11,'0');
               encoded = AddCheckDigit(encoded);
               encoded = encoded.PadLeft(14, '0');
               EmbeddedPrice = Convert.ToInt32(embedded);
            }
            return (encoded);
        }
        #endregion


    }
}
