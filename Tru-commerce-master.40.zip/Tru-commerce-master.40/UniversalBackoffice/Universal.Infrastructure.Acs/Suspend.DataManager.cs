﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Universal.Core.Model;
using Universal.Infrastructure.Acs.IO;

/// <summary>
/// doesn't fully work yet
/// </summary>

namespace Universal.Infrastructure.Acs
{
   public class SrtermKey
   {
      public int Terminal { get; set; }
      public int Transaction { get; set; }
      public int NumRecs { get; set; }
      public int BusinessDay { get; set; }
   }
   public partial class DataManager
   {
      public int GetBusinessDay()
      {
         int businessDay = 0;
         lock (_classLock)
         {
            string TCFfile = "TCF";
            Tms _Tms = new Tms();

            if (_Tms != null)
            {
               _Tms.Open("TCF");
               AcsFile file = _Fd.Files.Where(s => s.Name == TCFfile).First();
               AcsRecord storeRecord = file.Records.Where(r => r.Name.ToUpper() == "STORE_TCF_REC").First();
               dynamic storeRecordDyn = _Fd.ToDynamic(storeRecord);
               byte[] binary = new byte[file.Max];
               storeRecordDyn.key_termid = 9999;
               AcsIO.ManagedToBinary(binary, storeRecord.Fields.Where(n => n.Name == "key_termid").First(), storeRecordDyn.key_termid);
               if (_Tms.Read(binary) == (short)Tms.Errors.OK)
               {
                  businessDay = AcsIO.BinaryToInt(binary, storeRecord.Fields.Where(r => r.Name.ToLower() == "curr_bus_day").First());
               }
               _Tms.Close();
            }
            if (businessDay == 0)
            {
               businessDay = DateTime.Now.DayOfYear;
            }
            return (businessDay);
         }
      }
      public int GetStoreNumber()
      {
         int storeNumber = 0;
         lock (_classLock)
         {
            string Descopfile = "DESCOP";
            Tms _Tms = new Tms();

            if (_Tms != null)
            {
               _Tms.Open(Descopfile);
               AcsFile file = _Fd.Files.Where(s => s.Name == Descopfile).First();
               AcsRecord record = file.Records.Where(r => r.Name.ToUpper() == "OPTIONS_DESC_STRUCT").First();
               dynamic recordDyn = _Fd.ToDynamic(record);
               byte[] binary = new byte[file.Max];

               AcsIO.ManagedToBinary(binary, record.Fields.Where(n => n.Name == "reserved_record").First(), 1);
               if (_Tms.Read(binary) == (short)Tms.Errors.OK)
               {
                  string  s = AcsIO.BinaryToString(binary, record.Fields.Where(r => r.Name.ToLower() == "store_num").First());
                  storeNumber = Convert.ToInt32(s);
               }
               _Tms.Close();
            }
            return (storeNumber);
         }
      }
      public void PutItemsInSuspendFile(PutTransaction trans)
      {

         int businessDay = GetBusinessDay();
         int storeNumber = GetStoreNumber();

         log.InfoFormat("PutTransaction Store = {0} Business Day = {1}", storeNumber, businessDay);

         if (trans.Header.Store != storeNumber)
         {
            log.InfoFormat("Store number provided:{0} does not match store number in options {1}", trans.Header.Store, storeNumber);
         }

         lock (_classLock)
         {
            string suspendfile = "SRTERM";
            Tms _Tms = new Tms();
            
            if (_Tms != null)
            {
               _Tms.Open(suspendfile, 0, true, true);
               AcsFile file = _Fd.Files.Where(s => s.Name == suspendfile).First();
               AcsRecord irecord = file.Records.Where(r => r.Name.ToUpper() == "SRTERM_DATA").First();
               byte[] binary = new byte[file.Max];
               int Entry = 0;
               int trans_amount = 0;
               #region put item
               foreach(PutItem pItem in trans.Items)
               {
 
                  int qty = pItem.Qty;
                  if (qty == 0) qty = 1;

                  #region figure out itemizers and flags
                  int flags = 0;
                  int itemizers = 0;
                  int tare = 0;

                  Product product = GetProduct(pItem.Item);


                  if (product != null)
                  {
                     pItem.Item = product.Id;  // set to encoded and padded
                     if (_Options.Departments != null)
                     {
                        foreach (dynamic d in _Options.Departments)
                        {
                           if (d.deptno == product.Department)
                           {
                              flags = d.flags;
                              itemizers = d.itemizers;
                              tare = d.tare_code;
                              break;
                           }
                        }


                        if (product.OverrideAttributes)
                        {
                           flags = product.Flags;
                           itemizers = product.Itemizers;
                           tare = product.Tare;
                        }
                     }
                     else
                     {
                        log.WarnFormat("{0} not  loaded", "DEPDEF");
                     }

                     if (Utils.IsBitSet(flags, 0))  // clear qty required
                     {
                        flags = Utils.TurnBitOff(flags, 0x00000001);
                     }
                   
                  }
                  else
                  {
                     log.WarnFormat("Item:{0} does not exist in PLU file", pItem.Item);
                     product = new Product();  // all will be zeros
                     if (!pItem.NSC2)  // can't sell NSC2 as a department just let it be NOF
                     {
                        if (UniversalConfig.Instance.Config.SellNOFasDeptartment)
                        {
                           pItem.Item = "00000000000000";
                           product.Department = pItem.DefaultDept;
                           log.WarnFormat("Item:{0} does not exist in PLU file, selling with department", pItem.Item, pItem.DefaultDept);
                        }
                     }
                  }
                  #endregion

                  while (qty-- > 0)
                  {
                     trans_amount += pItem.Price;
                     Entry++;
                     Array.Clear(binary, 0, binary.Length);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "key_term_num").First(), trans.Header.Terminal);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "key_trans_num").First(), trans.Header.Transaction);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "key_entry_num").First(), Entry);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "key_current_bus_day_id").First(), businessDay);//may need changed
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "rectype").First(), 73);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "entryid").First(), Entry);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "code").First(), pItem.Item);

 
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "itemizers").First(), itemizers);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "item_tare_code").First(), tare);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "department").First(), product.Department);
                     

                     if (pItem.PricePerPound > 0 && pItem.Wgt>0 || pItem.NSC2)
                     {
                        int embeddedPrice = 0;
                        pItem.Item = Utils.Encode(pItem.Item, ref embeddedPrice);
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "code").First(), AcsIO.Encode(pItem.Item));
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "imbedded_price").First(), pItem.Price);
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "price").First(), pItem.Price);
                        if (pItem.NSC2)
                        {
                           AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "format_code").First(), product.Price);
                        }
                        else
                        {
                           AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "format_code").First(), pItem.PricePerPound);
                        }
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "quanwgt").First(), pItem.Wgt);
                        // need to set flag 1
                        flags = 0;
                        flags = Utils.TurnBitOn(flags, 0x00000001);
                      
                     }
                     else if (pItem.Wgt == 0)
                     {
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "quanwgt").First(), 1);
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "price").First(), pItem.Price);
                        
                     }
                     else if (UniversalConfig.Instance.Config.PutTransaction.UseWeightProvided)
                     {
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "quanwgt").First(), pItem.Wgt);
                        AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "price").First(), pItem.Price);
                     }
                     else
                     {
                        //AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "price").First(), pItem.Price);
                        flags = 0;
                     }
                     if (UniversalConfig.Instance.Config.UsePOSPrice == false)
                     {
                        if (pItem.Wgt == 0)
                        {
                           flags = Utils.TurnBitOn(flags, 0x00000200);  //turn on price change flag so we can use web price
                        }
                     }
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "flags").First(), flags);

                     if (_Tms.Write(binary) != (short)Tms.Errors.OK)
                     {
                        // EOD will cleanup the orphans
                        break;
                     }
                  }
               }
               #region CM card
               if ((trans.Header.AltId != null && trans.Header.AltId != string.Empty) || ( trans.Header.Card != null && trans.Header.Card != string.Empty))
               {
                  Array.Clear(binary, 0, binary.Length);
                  Entry++;
                  //']' 93
                  AcsRecord MemberRec = new AcsRecord();
                  MemberRec.Name = "Member";
                  MemberRec.Length = 40;
                  MemberRec.Fields.Add(new AcsField() { Name = "key_term_num", Type = "UI", Offset = 0, Length = 2, ArrayLength = 0 });
                  MemberRec.Fields.Add(new AcsField() { Name = "key_trans_num", Type = "UL", Offset = 2, Length = 4, ArrayLength = 0 });
                  MemberRec.Fields.Add(new AcsField() { Name = "key_entry_num", Type = "UI", Offset = 6, Length = 2, ArrayLength = 0 });
                  MemberRec.Fields.Add(new AcsField() { Name = "key_current_bus_day_id", Type = "IN", Offset = 8, Length = 2, ArrayLength = 0 });
                  MemberRec.Fields.Add(new AcsField() { Name = "rectype", Type = "IN", Offset = 10, Length = 2, ArrayLength = 0 });
                  MemberRec.Fields.Add(new AcsField() { Name = "card", Type = "S3", Offset = 12, Length = 26, ArrayLength = 0 });
                  MemberRec.Fields.Add(new AcsField() { Name = "cardtype", Type = "IN", Offset = 38, Length = 2, ArrayLength = 0 });
                  dynamic srterm_cm = _Fd.ToDynamic(MemberRec);
                  AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "key_term_num").First(), trans.Header.Terminal);
                  AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "key_trans_num").First(), trans.Header.Transaction);
                  AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "key_entry_num").First(), Entry);
                  AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "key_current_bus_day_id").First(), businessDay);//may need changed
                  AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "rectype").First(), 93);
                  if (trans.Header.AltId != null)
                  {
                     AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "card").First(), trans.Header.AltId);//may need changed
                     AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "cardtype").First(), 4);
                  }
                  else
                  {
                     AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "card").First(), trans.Header.Card);//may need changed
                     AcsIO.ManagedToBinary(binary, MemberRec.Fields.Where(n => n.Name == "cardtype").First(), 0);
                     AcsIO.ManagedToBinary(binary, irecord.Fields.Where(n => n.Name == "cm_card_input").First(), trans.Header.Card);
                  }
                  if (_Tms.Write(binary) != (short)Tms.Errors.OK)
                  {
                     // EOD will cleanup the orphans
                  }
               }
               #endregion





               AcsRecord hrecord = file.Records.Where(r => r.Name.ToUpper() == "SRTERM_HDR").First();

               dynamic srterm_hdr = _Fd.ToDynamic(hrecord);
               Array.Clear(binary, 0, binary.Length);
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_term_num").First(), trans.Header.Terminal);
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_trans_num").First(), trans.Header.Transaction);
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_entry_num").First(), 10000);
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_current_bus_day_id").First(), businessDay);
               

               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "num_recs").First(), Entry);
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "fsr_type").First(), 0);
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "age_ver_customer_age").First(), 21);
               DateTime date = DateTime.Now;

               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "suspend_time").First(), date.Year - 1900);
               try
               {
                   AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "tlog_eot_timestamp_month").First(), date.Month);
                   AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "tlog_eot_timestamp_day").First(), date.Day);
                   AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "tlog_eot_timestamp_hour").First(), date.Hour);
                   AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "tlog_eot_timestamp_minute").First(), date.Second);
                       
               }
               catch
               {
               }
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "suspend_time").First(), Utils.ConvertToUnixTimestamp(DateTime.Now));

               int time_to_live = 0;
               try { time_to_live = UniversalConfig.Instance.Config.PutTransaction.TimeToLive; }catch { }
                  
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "time_to_live").First(), time_to_live);
               
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "trans_date").First(), businessDay);


               if (UniversalConfig.Instance.Config.Operator == null)
               {
                  AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "oper_num").First(), "7624");
               }
               else
               {
                  AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "oper_num").First(), UniversalConfig.Instance.Config.Operator);
               }
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "trans_amt").First(), trans_amount);
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "reason").First(), "eCart");
               AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "fsr_type").First(), 1);
               //Reason code 
               //Suspend type
               _Tms.Write(binary);

               #endregion
               _Tms.Close();
            }
         }
      }
      public bool FlushSuspendsByTimeToLive()
      {
         int businessDay = GetBusinessDay();
         lock (_classLock)
         {
            string suspendfile = "SRTERM";
            Tms _Tms = new Tms();
            List <SrtermKey> keys = new List<SrtermKey>();

            if (_Tms != null)
            {
               _Tms.Open(suspendfile, 0, true, true);
               AcsFile file = _Fd.Files.Where(s => s.Name == suspendfile).First();
               AcsRecord hrecord = file.Records.Where(r => r.Name.ToUpper() == "SRTERM_HDR").First();
               byte[] binary = new byte[file.Max];

               _Tms.First = true;
               short TmsErrror = (short)Tms.Errors.OK;
               while (TmsErrror == (short)Tms.Errors.OK)
               {
                  if (_Tms.GetNext(binary) != (short)Tms.Errors.OK)
                  {
                     break;
                  }
                  dynamic srterm_hdr = _Fd.ToDynamic(hrecord, binary);
                  if (srterm_hdr == null)
                  {
                     continue;   //not a header
                  }
                  if (srterm_hdr.key_entry_num == 10000)
                  {
                     if((srterm_hdr.trans_date + srterm_hdr.time_to_live)< businessDay)
                     {
                        keys.Add(new SrtermKey() {
                           Terminal = srterm_hdr.key_term_num,
                           Transaction = srterm_hdr.key_trans_num,
                           BusinessDay = srterm_hdr.key_current_bus_day_id,
                           NumRecs = srterm_hdr.num_recs
                        });
                     }
                  }
               }
               foreach (SrtermKey key in keys)
               {
                  Array.Clear(binary, 0, binary.Length);
                  AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_term_num").First(), key.Terminal);
                  AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_trans_num").First(), key.Transaction);
                  AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_current_bus_day_id").First(), key.BusinessDay);
                  TmsErrror = (short)Tms.Errors.OK;
                  int index = 0;
                  while (TmsErrror == (short)Tms.Errors.OK)
                  {
                     index++;
                     AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_entry_num").First(), index);
                     TmsErrror = _Tms.Delete(binary);
                  }
                  index = 0;
                  TmsErrror = (short)Tms.Errors.OK;
                  while (TmsErrror == (short)Tms.Errors.OK)
                  {
                     index++;
                     AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_entry_num").First(), 11000 + index);
                     TmsErrror = _Tms.Delete(binary);
                  }
                  AcsIO.ManagedToBinary(binary, hrecord.Fields.Where(n => n.Name == "key_entry_num").First(), 10000);
                  TmsErrror = _Tms.Delete(binary);
               }

               _Tms.Close();
            }
         }
         return (true);
      }
   }
}
