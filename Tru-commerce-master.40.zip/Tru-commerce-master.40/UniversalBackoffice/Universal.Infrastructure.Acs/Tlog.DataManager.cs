﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Universal.Core.Model;
using Universal.Infrastructure.Acs.IO;

/// <summary>
/// doesn't fully work yet
/// </summary>

namespace Universal.Infrastructure.Acs
{
   public partial class DataManager
   {
      private byte[] CreateHeader(TcfInfo tcfInfo, PutTransaction p , int sequence, bool last)
      {
         TlogRecord tblock = _Fd.Tlog.Records.Where(r => r.Name.ToUpper() == "GTLTBH").First();
         byte[] binary = new byte[tblock.Length];
         AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "type").First(), 0x42);
         AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "tlog_seq_count").First(), tcfInfo.SequenceCounter);
         AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "terminal").First(), p.Header.Terminal);
         AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "sequence").First(), sequence);
         if (last)
         {
            AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "numblock").First(), 0xffff);
         }
         else
         {
            AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "numblock").First(), 0x00);
         }
         AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "tnum").First(), p.Header.Transaction);
         AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "non_reset_tnum").First(), p.Header.Transaction);
         AcsIO.ManagedToBinary(binary, tblock.Fields.Where(n => n.Name == "period").First(), tcfInfo.Period);
         return (binary);
      }
      private byte[] CreateExtended(int Size, int Type, int Offset, int Header)
      {
         TlogRecord extended = _Fd.Tlog.Records.Where(r => r.Name.ToUpper() == "EXTEND").First();
         byte[] binary = new byte[extended.Length];

         AcsIO.ManagedToBinary(binary, extended.Fields.Where(n => n.Name == "extended_record_type").First(), 0xFF);
         AcsIO.ManagedToBinary(binary, extended.Fields.Where(n => n.Name == "size_of_entry").First(), Size);
         AcsIO.ManagedToBinary(binary, extended.Fields.Where(n => n.Name == "type_of_entry").First(), Type);
         AcsIO.ManagedToBinary(binary, extended.Fields.Where(n => n.Name == "offset_to_user_data").First(), Offset);
         AcsIO.ManagedToBinary(binary, extended.Fields.Where(n => n.Name == "hdr_version").First(), Header);

         return (binary);
      }
      private byte[] CreateLeader ( TcfInfo tcfInfo, PutTransaction p)
      {
         TlogRecord leader = _Fd.Tlog.Records.Where(r => r.Name.ToUpper() == "GTLLDR").First();
         byte[] binary = new byte[leader.Length + 1];

         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "type").First(),0x4e ); // 'N''G' signon 'F' signoff
         DateTime d = DateTime.Now;
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "month").First(), d.Month);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "day").First(), d.Day);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "year").First(), d.Year - 2000);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "hour").First(), d.Hour);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "minute").First(), d.Minute);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "second").First(), d.Second);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "operator").First(), p.Header.Operator);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "sgpos").First(), p.Header.GrossPositive);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "store_number").First(), p.Header.Store); // not sure if we want to get from here or options
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "numtrans").First(), 1);
         AcsIO.ManagedToBinary(binary, leader.Fields.Where(n => n.Name == "zip_code").First(), Options.Description.store_zipcode);

         binary[binary.Length - 1] = Convert.ToByte('Z');

         byte[] Extended = CreateExtended(leader.Length,0x4c, leader.Length, 0);

         return (Extended.Concat(binary).ToArray());
      }
      private byte[] CreateTax(TcfInfo tcfInfo, PutTransaction p)
      {
         TlogRecord tax = _Fd.Tlog.Records.Where(r => r.Name.ToUpper() == "GTLTAX").First();
         byte[] binary = new byte[tax.Length + 1];
         if (p.Header.Taxes.Count == 0)
         {
            AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "tax01").First(), p.Header.Tax);
         }
         else
         {
            PutTax t1 = p.Header.Taxes.Where(n => n.Code == 1).FirstOrDefault();
            if (t1 != null)
            {
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "tax01").First(), t1.Amount);
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "gross01").First(), t1.TaxableAmount);
            }
            PutTax t2 = p.Header.Taxes.Where(n => n.Code == 2).FirstOrDefault();
            if (t2 != null)
            {
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "tax02").First(), t2.Amount);
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "gross02").First(), t2.TaxableAmount);
            }
            PutTax t3 = p.Header.Taxes.Where(n => n.Code == 3).FirstOrDefault();
            if (t3 != null)
            {
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "tax03").First(), t3.Amount);
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "gross03").First(), t3.TaxableAmount);
            }
            PutTax t4 = p.Header.Taxes.Where(n => n.Code == 4).FirstOrDefault();
            if (t4 != null)
            {
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "tax04").First(), t4.Amount);
               AcsIO.ManagedToBinary(binary, tax.Fields.Where(n => n.Name == "gross04").First(), t4.TaxableAmount);
            }
         }
         binary[binary.Length - 1] = Convert.ToByte('Z');

         byte[] Extended = CreateExtended(tax.Length, 0x74, tax.Length, 0);

         return (Extended.Concat(binary).ToArray());
      }
      private byte[] CreateItem(TcfInfo tcfInfo, PutItem i, int entry)
      {
         
         TlogRecord item = _Fd.Tlog.Records.Where(r => r.Name.ToUpper() == "GTLITM").First();
         if (item.Length % 2 != 0)
         {
             item.Length++; // structure packing is 2 byte boundaries
         }
         byte[] binary = new byte[item.Length + 1];
         AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "code").First(), i.Item);
         AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "department").First(), i.DefaultDept);
         AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "sales_entryid").First(), entry);
         int flags = 0;
         if (i.Qty > 0)
         {
            AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "quanwgt").First(), i.Qty);
            AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "xprice").First(), i.Price* i.Qty);
         }
         else
         {
            AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "quanwgt").First(), i.Wgt);
            double p = i.Price * i.Wgt;
            int price = Convert.ToInt32(Math.Round(p / 100, 0, MidpointRounding.AwayFromZero));
            AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "xprice").First(), price);

            flags = Utils.TurnBitOn(flags, 0x00000001);  //set the weight flag
         }
         AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "flags").First(), flags);
         if (i.product != null)
         {
            AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "itemizers").First(), i.product.Itemizers);
            AcsIO.ManagedToBinary(binary, item.Fields.Where(n => n.Name == "department").First(), i.product.Department);
         }
         binary[binary.Length - 1] = Convert.ToByte('Z');

         byte[] Extended = CreateExtended(item.Length, 0x49, item.Length, 0);

         return (Extended.Concat(binary).ToArray());

      }
      private byte[] CreateTender(TcfInfo tcfInfo, PutTender t)
      {
         TlogRecord tender = _Fd.Tlog.Records.Where(r => r.Name.ToUpper() == "GTLTEN").First();
         byte[] binary = new byte[tender.Length + 1];
         AcsIO.ManagedToBinary(binary, tender.Fields.Where(n => n.Name == "type").First(), t.Type);
         AcsIO.ManagedToBinary(binary, tender.Fields.Where(n => n.Name == "amount").First(), t.Amount);
         binary[binary.Length - 1] = Convert.ToByte('Z');

         byte[] Extended = CreateExtended(tender.Length, 0x51, tender.Length, 0);

         return (Extended.Concat(binary).ToArray());

      }
      public void ProcessTlog(PutTransaction p, TcfInfo tcfInfo)
      {
         lock (_classLock)
         {
            Tms tlogTms = new Tms();
            if (tlogTms != null)
            {
               tlogTms.Open("TLOG");

 
               int sequence = 1;
               //do leader
               tlogTms.Write(
                   CreateHeader(tcfInfo, p, sequence,false)
                  .Concat(CreateLeader(tcfInfo, p)).ToArray());

               // do tax
               tlogTms.Write(CreateHeader(tcfInfo, p, ++sequence,false)
                             .Concat(CreateTax(tcfInfo, p)).ToArray());

               // do items
               int entry = 0;
               foreach (PutItem i in p.Items)
               {
                  tlogTms.Write(CreateHeader(tcfInfo, p, ++sequence, false)
                               .Concat(CreateItem(tcfInfo, i,++entry)).ToArray());
 
               }
               // do tenders
               int tcount = p.Header.Tenders.Count;
               foreach (PutTender t in p.Header.Tenders)
               {
                  bool last = false;
                  if (tcount == 1) last = true;
                  tlogTms.Write(CreateHeader(tcfInfo, p, ++sequence,last)
                               .Concat(CreateTender(tcfInfo, t)).ToArray());
                  tcount--;
               }
               tlogTms.Close();
            }
         }
      }
   }
}
