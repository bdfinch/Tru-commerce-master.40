﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace Universal.Infrastructure.Acs
{
   // exceptions, paths do not exist, config file does not exist
   #region config file exceptions
   public class ConfigFileNotFoundException : Exception
   {
      public ConfigFileNotFoundException()
      {
      }

      public ConfigFileNotFoundException(string message)
          : base(message)
      {
      }

      public ConfigFileNotFoundException(string message, Exception inner)
          : base(message, inner)
      {
      }
   }
   public class BgfPathNotFoundException : Exception
   {
      public BgfPathNotFoundException()
      {
      }

      public BgfPathNotFoundException(string message)
          : base(message)
      {
      }

      public BgfPathNotFoundException(string message, Exception inner)
          : base(message, inner)
      {
      }
   }
   public class InfPathNotFoundException : Exception
   {
      public InfPathNotFoundException()
      {
      }

      public InfPathNotFoundException(string message)
          : base(message)
      {
      }

      public InfPathNotFoundException(string message, Exception inner)
          : base(message, inner)
      {
      }
   }
   public class WhiteListFileNotFoundException : Exception
   {
      public WhiteListFileNotFoundException()
      {
      }

      public WhiteListFileNotFoundException(string message)
          : base(message)
      {
      }

      public WhiteListFileNotFoundException(string message, Exception inner)
          : base(message, inner)
      {
      }
   }

   #endregion

   public class PutTransactionOptions
   {
      public bool UseWeightProvided { get; set; }
      public int TimeToLive { get; set; }

   }
   public class Config
   {
      public string Enterprise { get; set; }
      public string BgfPath { get; set; }
      public string InfPath { get; set; }
      public string TlogPath { get; set; }
      public int RestartHour { get; set; }
      public bool UsePOSPrice { get; set; }
      public bool SellNOFasDeptartment { get; set; }
      public bool DoNotPingTms { get; set; }
      public List<string> WhiteList { get; set; }
      public List<string> BlackList { get; set; }
      public string Operator { get; set; }

      public PutTransactionOptions PutTransaction { get; set; }
      public Config()
      {
         WhiteList = new List<string>();
         BlackList = new List<string>();
         PutTransaction = new PutTransactionOptions();
      }
   }
   public class UniversalConfig
   {
      private static volatile UniversalConfig instance;
      private static Object _classLock = typeof(UniversalConfig);
      private Config _Config = null;
      public Config Config
      {
         get
         {
            return _Config;
         }
         set
         {
            if (_Config == null)
            {
               // only allow this to be set once
               _Config = value;
               if (!Directory.Exists(_Config.BgfPath))
               {
                  throw new BgfPathNotFoundException("BGF path " + _Config.BgfPath + " does not exist");
               }
               if (!Directory.Exists(_Config.InfPath))
               {
                  throw new InfPathNotFoundException("INF path " + _Config.InfPath + " does not exist");
               }
               if (_Config.WhiteList.Count > 0)
               {
                  foreach (string w in _Config.WhiteList)
                  {
                     if (w.ToLower() == "tlog")
                     {
                        continue;
                     }
                     string wf = _Config.BgfPath + "\\" + w.ToLower() + ".bgf";
                     if (!File.Exists(wf))
                     {
                        throw new InfPathNotFoundException("No BGF match found for whitelist file " + wf);
                     }
                  }
               }
            }
         }
      }
      public static UniversalConfig Instance
      {
         get
         {
            if (instance == null)
            {
               lock (_classLock)
               {
                  if (instance == null)
                     instance = new UniversalConfig();
               }
            }
            return instance;
         }
      }
   }
}
