﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Universal.Core.Model;

namespace Universal.Core.Interfaces
{
   public interface IProductRepository
   {
      void Add(Product p);
      void Edit(Product p);
      void Remove(string ProductID);
      IEnumerable<Product> GetProducts();
      Product GetProduct(string Id);
   }
}
