﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Universal.Core.Model;

namespace Universal.Core.Interfaces
{
   public interface IStoreSalesRepository
   {
      StoreSales Get();
   }
}
