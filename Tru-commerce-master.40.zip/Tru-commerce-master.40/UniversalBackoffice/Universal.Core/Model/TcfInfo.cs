﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Universal.Core.Model
{
   public class TcfInfo
   {
      public int SequenceCounter { get; set; }
      public int Period { get; set; }

      public bool EodInProgress { get; set; }
   }
}
