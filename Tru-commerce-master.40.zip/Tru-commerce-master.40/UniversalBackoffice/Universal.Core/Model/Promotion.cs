﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Core.Model
{
   public class Promotion
   {
      public uint Number { get; set; }
      public string Description { get; set; }
      public List<string> Conditions { get; set; }
      public List<string> Rewards { get; set; }
      public Promotion()
      {
         List<string> Conditions = new List<string>();
         List<string> Rewards = new List<string>();
      }
   }
}
