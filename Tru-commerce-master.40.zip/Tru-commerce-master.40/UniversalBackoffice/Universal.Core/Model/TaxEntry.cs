﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Universal.Core.Model
{
   public class TaxEntry
   {
      public int Type { get; set; }
      public Int32 Tax { get; set; }
      public Int32 GrossSales { get; set; }
      public Int32 TaxExemptSales { get; set; }
      public Int32 TaxExemptCount { get; set; }
      public Int32 TaxExemptTax { get; set; }
      public Int32 FsTaxForgiveSal { get; set; }
      public Int32 FsTaxForgiveTax { get; set; }

   }
}
