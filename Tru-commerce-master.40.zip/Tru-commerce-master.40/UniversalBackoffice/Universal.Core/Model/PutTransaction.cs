﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Universal.Core.Model
{
   
   public class PutTax
   {
      public int Code { get; set; }
      public int Amount { get; set; }
      public int TaxableAmount { get; set; }
   }
   public class PutTender
   {
      public int Type { get; set; }
      public int Amount { get; set; }

   }
   public class Header
   {
      public string Operator { get; set; }
      public int Terminal { get; set; }
      public int Transaction { get; set; }
      public int Store { get; set; }
      public string Card { get; set; }
      public string AltId { get; set; }
      public int Tax { get; set; }
      public int GrossPositive { get; set; }
      public List<PutTender> Tenders { get; set; }
      public List<PutTax> Taxes { get; set; }
      public Header()
      {
         Tenders = new List<PutTender>();
         Taxes = new List<PutTax>();
      }
   }
   public class PutItem
   {
      public string Item { get; set; }
      public int Price { get; set; }
      public int DefaultDept { get; set; }
      public int Qty { get; set; }
      public int Wgt { get; set; }
      public int PricePerPound { get; set; }
      public int AgeCode { get; set; }
      public bool NSC2 { get; set; }
      public Product product { get; set; }
}
   public class PutTransaction
   {
      public Header Header { get; set; }
      public List<PutItem> Items { get; set; }
      public PutTransaction()
      {
         Items = new List<PutItem>();
         Header = new Header();
      }
   }
}
