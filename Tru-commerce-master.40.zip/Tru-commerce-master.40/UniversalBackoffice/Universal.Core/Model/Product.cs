﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Universal.Core.Model
{

   public class Pricing
   {
      int Method { get; set; }                //1,2,3,4,5,6,7,8,9
      int BasePrice { get; set; }             //1,2,3,4,5,6,7,8,9
      int ForPrice { get; set; }              //  2,3,4,5,6,7,8,9
      int ForQty { get; set; }                //  2,3,4,5,6,7,8,9
      int DiscountPrice { get; set; }         //  2,3,4,5,6,7,8,9
      int DiscountQty { get; set; }           //  2,3,4,5,6,7,8,9
      int PromotionalPrice { get; set; }      //  2,3,4,5,6,7,8,9
      int PromotionalQty { get; set; }        //  2,3,4,5,6,7,8,9
      int MixMatchCode { get; set; }          //  2,3,4,5,6,7,8,9
      int SuggestedRetailPrice { get; set; }  //1,2,3,4,5,6,7,8,9
      int[] MinimunOrderAmount { get; set; }  //  2,3,4,5,6,7,8,9
      int[] PromotionalPricePer { get; set; } //  2,3,4,5,6,7,8,9


   }
   public class Product
   {
      public string Id { get; set; }
      public string Description { get; set; }
      public int Department { get; set; }
      public int Price { get; set; }
      public int Tare { get; set; }
      public int Itemizers { get; set; }
      public int Flags { get; set; }
      public int ExtendedItemizers { get; set; }
      public int ExtendedFlags { get; set; }
      public bool OverrideAttributes { get; set; }
      public List<Promotion> Promotions { get; set; }
    
      public Product()
      {
         Promotions = new List<Promotion>();
      }
   }
}
