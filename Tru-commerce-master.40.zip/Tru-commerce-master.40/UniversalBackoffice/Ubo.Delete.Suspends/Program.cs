﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Universal.Core.Model;
using Universal.Infrastructure.Acs;

namespace Ubo.Delete.Suspends
{
   class Program
   {
      static void Main(string[] args)
      {
         UniversalConfig config = UniversalConfig.Instance;
         string configfilename = "Universal.Config.json";
         if (!File.Exists(configfilename))
         {
            Console.WriteLine("{0} does not exist",configfilename);
            return;
         }
         config.Config = JsonConvert.DeserializeObject<Config>(File.ReadAllText(configfilename));
         DataManager dm = DataManager.Instance;
         dm.FlushSuspendsByTimeToLive();

      }
   }
}
